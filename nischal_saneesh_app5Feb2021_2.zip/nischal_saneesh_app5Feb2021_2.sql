-- MySQL dump 10.16  Distrib 10.1.47-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: nischal_saneesh_app
-- ------------------------------------------------------
-- Server version	10.1.47-MariaDB-0ubuntu0.18.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `account_head`
--

DROP TABLE IF EXISTS `account_head`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `account_head` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `financial_type1_id` int(11) NOT NULL,
  `financial_type2_id` int(11) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` int(11) NOT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `updated_by` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `account_head`
--

LOCK TABLES `account_head` WRITE;
/*!40000 ALTER TABLE `account_head` DISABLE KEYS */;
INSERT INTO `account_head` VALUES (8,'Purchase',11,2,1,'2020-09-29 22:40:27',1,'2020-09-29 22:40:27',0),(9,'Revenue',10,1,1,'2020-09-30 02:44:25',1,'2020-12-24 05:08:26',1),(10,'Opening Cash',11,5,1,'2020-10-01 23:49:28',1,'2020-10-01 23:49:28',0),(11,'Current Asset',11,5,1,'2020-12-17 22:51:37',1,'2021-01-06 02:48:26',1),(14,'Cost of Revenue',10,2,1,'2020-12-26 02:35:24',1,'2020-12-29 11:00:51',1),(16,'Expense',10,4,1,'2020-12-18 01:47:01',1,'2020-12-18 01:47:32',1),(19,'Income',10,3,1,'2020-12-29 08:09:45',1,'2020-12-29 08:09:45',0),(23,'Current Liability',11,7,1,'2021-01-19 05:01:48',1,'2021-01-19 05:01:48',0),(24,'Equity',11,9,1,'2021-01-26 05:58:44',1,'2021-01-26 05:58:44',0);
/*!40000 ALTER TABLE `account_head` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `account_transitions`
--

DROP TABLE IF EXISTS `account_transitions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `account_transitions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `vochur_no` varchar(255) NOT NULL,
  `transition_date` date NOT NULL,
  `sub_account_id` int(11) NOT NULL,
  `customer_id` int(11) DEFAULT NULL,
  `supplier_id` int(11) DEFAULT NULL,
  `receipt_id` int(11) DEFAULT NULL,
  `payment_id` int(11) DEFAULT NULL,
  `purchase_id` int(11) DEFAULT NULL,
  `sale_id` int(11) DEFAULT NULL,
  `credit` int(11) DEFAULT NULL,
  `debit` int(11) DEFAULT NULL,
  `is_cashbook` tinyint(4) NOT NULL DEFAULT '1',
  `description` text,
  `status` varchar(60) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` int(11) NOT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `updated_by` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=57 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `account_transitions`
--

LOCK TABLES `account_transitions` WRITE;
/*!40000 ALTER TABLE `account_transitions` DISABLE KEYS */;
INSERT INTO `account_transitions` VALUES (1,'C00001','2021-01-05',10,4,NULL,NULL,NULL,NULL,1,NULL,3000000,1,'Inv C00001,Inv Date 2021-01-05 to မသဇင်-ရာမာန်-မော်လမြိုင်','credit_collection','2021-01-18 09:18:50',0,'2021-01-18 09:18:50',0),(2,'C00001','2021-01-05',10,4,NULL,NULL,NULL,NULL,1,NULL,3000000,0,'','credit_collection','2021-01-18 09:18:50',0,'2021-01-18 09:18:50',0),(3,'C00002','2021-01-08',10,7,NULL,NULL,NULL,NULL,2,NULL,5000000,1,'Inv C00002,Inv Date 2021-01-08 to ကိုတရုတ်-ရေး','credit_collection','2021-01-21 07:30:22',0,'2021-01-21 07:30:22',0),(4,'C00002','2021-01-08',10,7,NULL,NULL,NULL,NULL,2,NULL,5000000,0,'','credit_collection','2021-01-21 07:30:22',0,'2021-01-21 07:30:22',0),(5,'C00003','2021-01-08',10,20,NULL,NULL,NULL,NULL,3,NULL,7330950,1,'Inv C00003,Inv Date 2021-01-08 to ကိုရာဇာ K-Star-မြဝတီ','credit_collection','2021-01-21 07:39:46',0,'2021-01-21 07:39:46',0),(6,'C00003','2021-01-08',10,20,NULL,NULL,NULL,NULL,3,NULL,7330950,0,'','credit_collection','2021-01-21 07:39:46',0,'2021-01-21 07:39:46',0),(18,'','2020-12-31',26,NULL,NULL,NULL,NULL,NULL,NULL,NULL,18528895,0,NULL,NULL,'2021-01-27 11:05:33',1,NULL,1),(19,'','2020-12-31',27,NULL,NULL,NULL,NULL,NULL,NULL,NULL,67748352,0,NULL,NULL,'2021-01-27 11:10:56',1,NULL,1),(20,'','2020-12-31',28,NULL,NULL,NULL,NULL,NULL,NULL,NULL,7700,0,NULL,NULL,'2021-01-27 11:14:51',1,NULL,1),(21,'','2020-12-31',34,NULL,NULL,NULL,NULL,NULL,NULL,4011780,NULL,0,NULL,NULL,'2021-01-27 11:16:18',1,NULL,1),(22,'','2020-12-31',29,NULL,NULL,NULL,NULL,NULL,NULL,77273877,NULL,0,NULL,NULL,'2021-01-27 11:17:09',1,NULL,1),(23,'','2020-12-31',30,NULL,NULL,NULL,NULL,NULL,NULL,200000,NULL,0,NULL,NULL,'2021-01-27 11:19:21',1,NULL,1),(24,'','2020-12-31',31,NULL,NULL,NULL,NULL,NULL,NULL,3545,NULL,0,NULL,NULL,'2021-01-27 11:19:21',1,NULL,1),(25,'','2020-12-31',32,NULL,NULL,NULL,NULL,NULL,NULL,210000,NULL,0,NULL,NULL,'2021-01-27 11:20:57',1,NULL,1),(26,'','2020-12-31',33,NULL,NULL,NULL,NULL,NULL,NULL,4585745,NULL,0,NULL,NULL,'2021-01-27 11:20:57',1,NULL,1),(27,'C00004','2021-01-08',10,18,NULL,NULL,NULL,NULL,4,NULL,4229700,1,'Inv C00004,Inv Date 2021-01-08 to ကိုယူဂျင်းဌေး-ကျေးဇူးတော်-ဖယ်ခုံ','credit_collection','2021-02-03 09:04:49',0,'2021-02-03 09:04:49',0),(28,'C00004','2021-01-08',10,18,NULL,NULL,NULL,NULL,4,NULL,4229700,0,'','credit_collection','2021-02-03 09:04:49',0,'2021-02-03 09:04:49',0),(29,'C00005','2021-01-08',10,21,NULL,NULL,NULL,NULL,5,NULL,1842000,1,'Inv C00005,Inv Date 2021-01-08 to ကိုသိန်းနိုင်-မြိုင်ကလေး','credit_collection','2021-02-03 09:05:36',0,'2021-02-03 09:05:36',0),(30,'C00005','2021-01-08',10,21,NULL,NULL,NULL,NULL,5,NULL,1842000,0,'','credit_collection','2021-02-03 09:05:36',0,'2021-02-03 09:05:36',0),(31,'C00005','2021-01-08',14,21,NULL,NULL,NULL,NULL,5,NULL,500,0,'','discount_allowed','2021-02-03 09:05:36',0,'2021-02-03 09:05:36',0),(32,'C00006','2021-01-11',10,27,NULL,NULL,NULL,NULL,6,NULL,1859000,1,'Inv C00006,Inv Date 2021-01-11 to မခင်ချိုဝင်းချမ်းသာသုခ-ကျိုက်ထို','credit_collection','2021-02-03 09:08:32',0,'2021-02-03 09:08:32',0),(33,'C00006','2021-01-11',10,27,NULL,NULL,NULL,NULL,6,NULL,1859000,0,'','credit_collection','2021-02-03 09:08:32',0,'2021-02-03 09:08:32',0),(34,'C00007','2021-01-15',10,19,NULL,NULL,NULL,NULL,7,NULL,15271200,1,'Inv C00007,Inv Date 2021-01-15 to ကိုကျော်ဆန်းဝင်း-မြဝတီ','credit_collection','2021-02-03 09:11:04',0,'2021-02-03 09:11:04',0),(35,'C00007','2021-01-15',10,19,NULL,NULL,NULL,NULL,7,NULL,15271200,0,'','credit_collection','2021-02-03 09:11:04',0,'2021-02-03 09:11:04',0),(36,'C00008','2021-01-15',10,7,NULL,NULL,NULL,NULL,8,NULL,674400,1,'Inv C00008,Inv Date 2021-01-15 to ကိုတရုတ်-ရေး','credit_collection','2021-02-03 09:11:46',0,'2021-02-03 09:11:46',0),(37,'C00008','2021-01-15',10,7,NULL,NULL,NULL,NULL,8,NULL,674400,0,'','credit_collection','2021-02-03 09:11:46',0,'2021-02-03 09:11:46',0),(38,'C00009','2021-01-15',10,7,NULL,NULL,NULL,NULL,9,NULL,1992683,1,'Inv C00009,Inv Date 2021-01-15 to ကိုတရုတ်-ရေး','credit_collection','2021-02-03 09:13:29',0,'2021-02-03 09:13:29',0),(39,'C00009','2021-01-15',10,7,NULL,NULL,NULL,NULL,9,NULL,1992683,0,'','credit_collection','2021-02-03 09:13:29',0,'2021-02-03 09:13:29',0),(40,'C00010','2021-02-18',10,4,NULL,NULL,NULL,NULL,10,NULL,739200,1,'Inv C00010,Inv Date 2021-02-18 to မသဇင်-ရာမာန်-မော်လမြိုင်','credit_collection','2021-02-03 09:26:45',0,'2021-02-03 09:26:45',0),(41,'C00010','2021-02-18',10,4,NULL,NULL,NULL,NULL,10,NULL,739200,0,'','credit_collection','2021-02-03 09:26:45',0,'2021-02-03 09:26:45',0),(42,'CR00001','2021-01-05',24,NULL,NULL,4,NULL,NULL,NULL,NULL,2,1,'Bank ပိုထုတ္','receipt','2021-02-03 09:48:22',4,'2021-02-03 09:52:33',4),(44,'CR00005','2021-01-06',30,NULL,NULL,5,NULL,NULL,NULL,NULL,10139700,1,'Deepa မွေခ်းေငြ','receipt','2021-02-03 09:49:03',0,'2021-02-03 09:49:03',0),(45,'CR00005','2021-01-06',30,NULL,NULL,5,NULL,NULL,NULL,10139700,NULL,0,'Deepa မွေခ်းေငြ','receipt','2021-02-03 09:49:03',0,'2021-02-03 09:49:03',0),(46,'CR00006','2021-01-08',35,NULL,NULL,6,NULL,NULL,NULL,NULL,50,1,'K Star ပိုေငြ','receipt','2021-02-03 09:49:42',0,'2021-02-03 09:49:42',0),(47,'CR00006','2021-01-08',35,NULL,NULL,6,NULL,NULL,NULL,50,NULL,0,'K Star ပိုေငြ','receipt','2021-02-03 09:49:42',0,'2021-02-03 09:49:42',0),(48,'CR00001','2021-01-05',24,NULL,NULL,4,NULL,NULL,NULL,2,NULL,0,'Bank ပိုထုတ္','receipt','2021-02-03 09:52:33',0,'2021-02-03 09:52:33',0),(49,'CP00001','2021-01-05',36,NULL,NULL,NULL,2,NULL,NULL,336000,NULL,1,'Ko Chan Commission','payment','2021-02-03 09:53:53',0,'2021-02-03 09:53:53',0),(50,'CP00001','2021-01-05',36,NULL,NULL,NULL,2,NULL,NULL,NULL,336000,0,'Ko Chan Commission','payment','2021-02-03 09:53:53',0,'2021-02-03 09:53:53',0),(51,'CP00003','2021-01-05',37,NULL,NULL,NULL,3,NULL,NULL,500,NULL,1,'Online Charges','payment','2021-02-03 09:55:19',0,'2021-02-03 09:55:19',0),(52,'CP00003','2021-01-05',37,NULL,NULL,NULL,3,NULL,NULL,NULL,500,0,'Online Charges','payment','2021-02-03 09:55:19',0,'2021-02-03 09:55:19',0),(53,'CP00004','2021-01-08',14,NULL,NULL,NULL,4,NULL,NULL,10,NULL,1,NULL,'payment','2021-02-03 10:11:37',0,'2021-02-03 10:11:37',0),(54,'CP00004','2021-01-08',14,NULL,NULL,NULL,4,NULL,NULL,NULL,10,0,NULL,'payment','2021-02-03 10:11:37',0,'2021-02-03 10:11:37',0),(55,'CP00005','2021-01-08',30,NULL,NULL,NULL,5,NULL,NULL,10139700,NULL,1,'Deepa ေခ်းေငြျပန္ဆပ္','payment','2021-02-04 05:13:16',0,'2021-02-04 05:13:16',0),(56,'CP00005','2021-01-08',30,NULL,NULL,NULL,5,NULL,NULL,NULL,10139700,0,'Deepa ေခ်းေငြျပန္ဆပ္','payment','2021-02-04 05:13:16',0,'2021-02-04 05:13:16',0);
/*!40000 ALTER TABLE `account_transitions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `account_types`
--

DROP TABLE IF EXISTS `account_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `account_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `account_types`
--

LOCK TABLES `account_types` WRITE;
/*!40000 ALTER TABLE `account_types` DISABLE KEYS */;
INSERT INTO `account_types` VALUES (1,'Customer'),(2,'Supplier'),(3,'Other'),(4,'Cash'),(5,'Cash & Bank');
/*!40000 ALTER TABLE `account_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `branch_user`
--

DROP TABLE IF EXISTS `branch_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `branch_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `branch_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `branch_user`
--

LOCK TABLES `branch_user` WRITE;
/*!40000 ALTER TABLE `branch_user` DISABLE KEYS */;
INSERT INTO `branch_user` VALUES (4,2,1),(2,3,1),(3,4,1);
/*!40000 ALTER TABLE `branch_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `branches`
--

DROP TABLE IF EXISTS `branches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `branches` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `branch_name` varchar(255) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` int(11) NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `branch_name` (`branch_name`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `branches`
--

LOCK TABLES `branches` WRITE;
/*!40000 ALTER TABLE `branches` DISABLE KEYS */;
INSERT INTO `branches` VALUES (1,'Main Branch',1,1,'2020-10-05 06:46:53',1,'2020-08-10 17:30:00');
/*!40000 ALTER TABLE `branches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `brands`
--

DROP TABLE IF EXISTS `brands`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `brands` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `brand_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `country_head_id` int(11) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` int(11) NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `brands`
--

LOCK TABLES `brands` WRITE;
/*!40000 ALTER TABLE `brands` DISABLE KEYS */;
INSERT INTO `brands` VALUES (1,'GI Hollow Pipe',NULL,1,2,'2021-01-19 07:16:46',0,'2021-01-19 07:16:46'),(2,'I Beam',NULL,1,2,'2021-01-19 07:17:34',0,'2021-01-19 07:17:34'),(3,'U Beam',NULL,1,2,'2021-01-19 07:17:44',0,'2021-01-19 07:17:44'),(4,'HRB 400 Deformed Bar',NULL,1,2,'2021-01-19 07:18:07',0,'2021-01-19 07:18:07'),(5,'Angle',NULL,1,2,'2021-01-19 07:18:17',0,'2021-01-19 07:18:17'),(6,'Flat Bar',NULL,1,2,'2021-01-19 07:19:27',0,'2021-01-19 07:19:27'),(7,'Coil',NULL,1,2,'2021-01-19 07:19:48',0,'2021-01-19 07:19:48'),(8,'GI Round Pipe',NULL,1,2,'2021-01-19 07:20:22',0,'2021-01-19 07:20:22'),(9,'Stainless Steel',NULL,1,4,'2021-01-19 08:30:24',0,'2021-01-19 08:30:24'),(10,'Deck Panel',NULL,1,4,'2021-01-19 08:50:39',0,'2021-01-19 08:50:39');
/*!40000 ALTER TABLE `brands` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `brand_id` int(11) DEFAULT NULL,
  `category_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` int(11) NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` VALUES (1,1,'GI Hollow Pipe',1,2,'2021-01-19 07:21:46',0,'2021-01-19 07:21:46'),(2,5,'Angle',1,4,'2021-01-19 08:09:41',0,'2021-01-19 08:09:41'),(3,4,'HRB 400 Deformed Bar',1,4,'2021-01-19 08:13:19',0,'2021-01-19 08:13:19'),(4,7,'Coil',1,4,'2021-01-19 08:21:05',4,'2021-01-19 08:21:05'),(5,8,'GI Round Pipe',1,4,'2021-01-19 08:22:46',0,'2021-01-19 08:22:46'),(6,2,'I Beam',1,4,'2021-01-19 08:24:05',0,'2021-01-19 08:24:05'),(7,9,'Stainless Steel',1,4,'2021-01-19 08:30:45',0,'2021-01-19 08:30:45'),(8,10,'Deck Panel',1,4,'2021-01-19 08:51:02',0,'2021-01-19 08:51:02');
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `collection_purchase`
--

DROP TABLE IF EXISTS `collection_purchase`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `collection_purchase` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `purchase_id` int(11) NOT NULL,
  `purchase_collection_id` int(11) NOT NULL,
  `paid_amount` int(11) NOT NULL,
  `discount` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `collection_purchase`
--

LOCK TABLES `collection_purchase` WRITE;
/*!40000 ALTER TABLE `collection_purchase` DISABLE KEYS */;
/*!40000 ALTER TABLE `collection_purchase` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `collection_sale`
--

DROP TABLE IF EXISTS `collection_sale`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `collection_sale` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sale_id` int(11) NOT NULL,
  `collection_id` int(11) NOT NULL,
  `paid_amount` int(11) NOT NULL,
  `discount` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `collection_sale`
--

LOCK TABLES `collection_sale` WRITE;
/*!40000 ALTER TABLE `collection_sale` DISABLE KEYS */;
INSERT INTO `collection_sale` VALUES (1,20,1,3000000,NULL),(2,18,2,5000000,NULL),(3,11,3,7330950,NULL),(4,16,4,4229700,NULL),(5,10,5,1842000,500),(6,9,6,1859000,NULL),(7,13,7,15271200,NULL),(8,18,8,674400,NULL),(9,19,9,1992683,NULL),(10,20,10,739200,NULL);
/*!40000 ALTER TABLE `collection_sale` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `collections`
--

DROP TABLE IF EXISTS `collections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `collections` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `collection_no` varchar(100) NOT NULL,
  `collection_date` date NOT NULL,
  `branch_id` int(11) DEFAULT NULL,
  `customer_id` int(11) NOT NULL,
  `collect_type` varchar(10) DEFAULT NULL,
  `auto_payment` tinyint(1) DEFAULT '0',
  `total_paid_amount` int(11) NOT NULL,
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` int(11) NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `collection_no` (`collection_no`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `collections`
--

LOCK TABLES `collections` WRITE;
/*!40000 ALTER TABLE `collections` DISABLE KEYS */;
INSERT INTO `collections` VALUES (1,'C00001','2021-01-05',1,4,'cash',0,3000000,3,'2021-01-18 09:18:50',0,'2021-01-18 09:18:50'),(2,'C00002','2021-01-08',1,7,'cash',1,5000000,2,'2021-01-21 07:30:22',0,'2021-01-21 07:30:22'),(3,'C00003','2021-01-08',1,20,'cash',1,7330950,2,'2021-01-21 07:39:46',0,'2021-01-21 07:39:46'),(4,'C00004','2021-01-08',1,18,'cash',1,4229700,2,'2021-02-03 09:04:49',0,'2021-02-03 09:04:49'),(5,'C00005','2021-01-08',1,21,'cash',1,1842000,2,'2021-02-03 09:05:36',0,'2021-02-03 09:05:36'),(6,'C00006','2021-01-11',1,27,'cash',1,1859000,2,'2021-02-03 09:08:32',0,'2021-02-03 09:08:32'),(7,'C00007','2021-01-15',1,19,'cash',1,15271200,2,'2021-02-03 09:11:04',0,'2021-02-03 09:11:04'),(8,'C00008','2021-01-15',1,7,'cash',1,674400,2,'2021-02-03 09:11:46',0,'2021-02-03 09:11:46'),(9,'C00009','2021-01-15',1,7,'cash',1,1992683,2,'2021-02-03 09:13:29',0,'2021-02-03 09:13:29'),(10,'C00010','2021-02-18',1,4,'cash',1,739200,2,'2021-02-03 09:26:45',0,'2021-02-03 09:26:45');
/*!40000 ALTER TABLE `collections` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `colors`
--

DROP TABLE IF EXISTS `colors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `colors` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `color_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` int(11) NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`color_name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `colors`
--

LOCK TABLES `colors` WRITE;
/*!40000 ALTER TABLE `colors` DISABLE KEYS */;
/*!40000 ALTER TABLE `colors` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `countries`
--

DROP TABLE IF EXISTS `countries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `countries` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `country_name` varchar(255) CHARACTER SET utf8 NOT NULL,
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` int(11) NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `countries`
--

LOCK TABLES `countries` WRITE;
/*!40000 ALTER TABLE `countries` DISABLE KEYS */;
INSERT INTO `countries` VALUES (1,'Myanmar',1,'2020-10-05 06:13:33',1,'2020-05-06 17:30:00');
/*!40000 ALTER TABLE `countries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `countryhead_officesaleman`
--

DROP TABLE IF EXISTS `countryhead_officesaleman`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `countryhead_officesaleman` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `country_head_id` int(11) NOT NULL,
  `office_sale_man_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `countryhead_officesaleman`
--

LOCK TABLES `countryhead_officesaleman` WRITE;
/*!40000 ALTER TABLE `countryhead_officesaleman` DISABLE KEYS */;
/*!40000 ALTER TABLE `countryhead_officesaleman` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `credit_purchase_collections`
--

DROP TABLE IF EXISTS `credit_purchase_collections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `credit_purchase_collections` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `collection_no` varchar(255) NOT NULL,
  `collection_date` date NOT NULL,
  `supplier_id` int(11) NOT NULL,
  `branch_id` int(11) NOT NULL,
  `auto_payment` tinyint(4) NOT NULL DEFAULT '1',
  `total_paid_amount` bigint(20) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` int(11) NOT NULL,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `credit_purchase_collections`
--

LOCK TABLES `credit_purchase_collections` WRITE;
/*!40000 ALTER TABLE `credit_purchase_collections` DISABLE KEYS */;
/*!40000 ALTER TABLE `credit_purchase_collections` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customer_types`
--

DROP TABLE IF EXISTS `customer_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customer_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_type_name` varchar(255) CHARACTER SET utf8 NOT NULL,
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` int(11) NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer_types`
--

LOCK TABLES `customer_types` WRITE;
/*!40000 ALTER TABLE `customer_types` DISABLE KEYS */;
INSERT INTO `customer_types` VALUES (1,'Wholesale',1,'2020-10-05 01:18:17',1,'2020-10-05 01:18:17'),(2,'Retails',1,'2020-10-05 01:18:17',1,'2020-10-05 01:18:17');
/*!40000 ALTER TABLE `customer_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customers`
--

DROP TABLE IF EXISTS `customers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cus_code` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `cus_name` varchar(255) CHARACTER SET utf8 NOT NULL,
  `cus_phone` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `customer_type_id` int(11) NOT NULL,
  `country_id` int(11) NOT NULL,
  `state_id` int(11) NOT NULL,
  `township_id` int(11) NOT NULL,
  `cus_shipping_address` text COLLATE utf8_unicode_ci,
  `cus_billing_address` text CHARACTER SET utf8,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` int(11) NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `cus_code` (`cus_code`)
) ENGINE=MyISAM AUTO_INCREMENT=34 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customers`
--

LOCK TABLES `customers` WRITE;
/*!40000 ALTER TABLE `customers` DISABLE KEYS */;
INSERT INTO `customers` VALUES (1,'CU00001','ထိပ်တန်း-မြန်အောင်','09-951515002',1,1,1,17,'Myan Aung/မြန်အောင်','Myan Aung/မြန်အောင်',1,1,'2021-01-06 03:51:57',1,'2021-01-06 03:51:57',NULL),(2,'CU00002','ဟသာၤမင်း-မော်လမြိုင်','09-5822471',1,1,10,181,'MLM/မော်လမြိုင်','MLM/မော်လမြိုင်',1,1,'2021-01-06 03:51:57',1,'2021-01-06 03:51:57',NULL),(3,'CU00003','ကိုအာကာမောင်-ကော့သောင်း','09-422196798',1,1,18,295,'Kawthoung/ကော့သောင်း','Kawthoung/ကော့သောင်း',1,1,'2021-01-06 03:51:57',1,'2021-01-06 03:51:57',NULL),(4,'CU00004','မသဇင်-ရာမာန်-မော်လမြိုင်','09-425288292',1,1,10,181,'MLM/မော်လမြိုင်','MLM/မော်လမြိုင်',1,1,'2021-01-06 03:51:57',1,'2021-01-06 03:51:57',NULL),(5,'CU00005','မမွန်မွန်-ရာမာန်-မော်လမြိုင်','09-261744844',1,1,10,181,'MLM/မော်လမြိုင်','MLM/မော်လမြိုင်',1,1,'2021-01-06 03:51:57',1,'2021-01-06 03:51:57',NULL),(6,'CU00006','မမေမေဦး-sky-သထုံ','09-425267770',1,1,10,185,'Thaton/သထုံ','Thaton/သထုံ',1,1,'2021-01-06 03:51:57',1,'2021-01-06 03:51:57',NULL),(7,'CU00007','ကိုတရုတ်-ရေး','09-697373662',1,1,10,186,'Yae/ရေး','Yae/ရေး',1,1,'2021-01-06 03:51:57',1,'2021-01-06 03:51:57',NULL),(8,'CU00008','ကိုမျိုးဇော်ခိုင်-မော်လမြိုင်','09-425347917',1,1,10,181,'MLM/မော်လမြိုင်','MLM/မော်လမြိုင်',1,1,'2021-01-06 03:51:57',1,'2021-01-06 03:51:57',NULL),(9,'CU00009','ကိုသိန်းကို-အမရာ-တွံတေး','09-785478004',1,1,19,346,'Twan Te/တ ွံတေး','Twan Te/တ ွံတေး',1,1,'2021-01-06 03:51:57',1,'2021-01-06 03:51:57',NULL),(10,'CU00010','ကိုမင်းနိုင်-ရေး','09-9965187775',1,1,10,186,'Yae/ရေး','Yae/ရေး',1,1,'2021-01-06 03:51:57',1,'2021-01-06 03:51:57',NULL),(11,'CU00011','E.3-မ/ဥကလာ','09-625288828',1,1,19,331,'North Oakkalarpa/မြောက်ဥက္ကလာပ','North Oakkalarpa/မြောက်ဥက္ကလာပ',1,1,'2021-01-06 03:51:57',1,'2021-01-06 03:51:57',NULL),(12,'CU00012','ကိုစိုးနိုင်.နိုင်မောင်ခိုင်-မော်လမြိုင်','09-792354014',1,1,10,181,'MLM/မော်လမြိုင်','MLM/မော်လမြိုင်',1,1,'2021-01-06 03:51:57',1,'2021-01-06 03:51:57',NULL),(13,'CU00013','စံပြ-မော်လမြိုင်','09-425265663',1,1,10,181,'MLM/မော်လမြိုင်','MLM/မော်လမြိုင်',1,1,'2021-01-06 03:51:57',1,'2021-01-06 03:51:57',NULL),(14,'CU00014','ကိုလေး-သံဖြူဇရပ်','09-792591356',1,1,10,184,'Thanbyuzayat/သံဖြူဇရပ်','Thanbyuzayat/သံဖြူဇရပ်',1,1,'2021-01-06 03:51:57',1,'2021-01-06 03:51:57',NULL),(15,'CU00015','ကျော်-ဘားအံ','09-5660761',1,1,7,115,'Hpa An/ဖားအံ','Hpa An/ဖားအံ',1,1,'2021-01-06 03:51:57',1,'2021-01-06 03:51:57',NULL),(16,'CU00016','ကိုမောင်မောင်-ပေါင်းတည်','09-976215496',1,1,3,44,'Paung De/ပေါင်းတည်','Paung De/ပေါင်းတည်',1,1,'2021-01-06 03:51:57',1,'2021-01-06 03:51:57',NULL),(17,'CU00017','ရွှေပေါက်ကံ-သထုံ','09-972465539',1,1,10,185,'Thaton/သထုံ','Thaton/သထုံ',1,1,'2021-01-06 03:51:57',1,'2021-01-06 03:51:57',NULL),(18,'CU00018','ကိုယူဂျင်းဌေး-ကျေးဇူးတော်-ဖယ်ခုံ','09-250788500',1,1,6,349,'Phaekhone/ဖယ်ခုံ','Phaekhone/ဖယ်ခုံ',1,1,'2021-01-06 03:51:57',1,'2021-01-06 03:51:57',NULL),(19,'CU00019','ကိုကျော်ဆန်းဝင်း-မြဝတီ','09-799531777',1,1,7,116,'Myawaddy/မြဝတီ','Myawaddy/မြဝတီ',1,1,'2021-01-06 03:51:57',1,'2021-01-06 03:51:57',NULL),(20,'CU00020','ကိုရာဇာ K-Star-မြဝတီ','09-685021542',1,1,7,116,'Myawaddy/မြဝတီ','Myawaddy/မြဝတီ',1,1,'2021-01-06 03:51:57',1,'2021-01-06 03:51:57',NULL),(21,'CU00021','ကိုသိန်းနိုင်-မြိုင်ကလေး','09-767556343',1,1,8,125,'Myaing/မြိုင်','Myaing/မြိုင်',1,1,'2021-01-06 03:51:57',1,'2021-01-06 03:51:57',NULL),(22,'CU00022','ကိုအောင်ဆန်းဝင်း-ကမာမို','09-790471754',1,1,10,177,'Chaungzon Township/ချောင်းဇွန်','Chaungzon Township/ချောင်းဇွန်',1,1,'2021-01-06 03:51:57',1,'2021-01-06 03:51:57',NULL),(23,'CU00023','ဆောင်းသဇင်-မုဒုံ','09-5322486',1,1,10,182,'Mu Don/မုဒုံ','Mu Don/မုဒုံ',1,1,'2021-01-06 03:51:57',1,'2021-01-06 03:51:57',NULL),(24,'CU00024','ရွှေမြန်မာ-မော်လမြိုင်','09-979466575',1,1,10,181,'MLM/မော်လမြိုင်','MLM/မော်လမြိုင်',1,1,'2021-01-06 03:51:57',1,'2021-01-06 03:51:57',NULL),(25,'CU00025','ဘီလျံနာ-ဘားအံ','09-453397285',1,1,7,115,'Hpa An/ဖားအံ','Hpa An/ဖားအံ',1,1,'2021-01-06 03:51:57',1,'2021-01-06 03:51:57',NULL),(26,'CU00026','ဦးချစ်ဟို-မြိတ်','09-259395223',1,1,18,292,'Baik/မြိတ်','Baik/မြိတ်',1,1,'2021-01-06 03:51:57',1,'2021-01-06 03:51:57',NULL),(27,'CU00027','မခင်ချိုဝင်းချမ်းသာသုခ-ကျိုက်ထို','09-963466698',1,1,20,180,'Kyaikto/ကျိုက်ထို','Kyaikto/ကျိုက်ထို',1,1,'2021-01-06 03:51:57',1,'2021-01-06 03:51:57',NULL),(28,'CU00028','ကိုမောင်လေး-ဇဗ္မူထွန်း-ညောင်ရွှေ','09-770452900',1,1,21,282,'Nyaungshwe Township/ညောင်ရွှေ','Nyaungshwe Township/ညောင်ရွှေ',1,1,'2021-01-06 03:51:57',1,'2021-01-06 03:51:57',NULL),(29,'CU00029','ကိုစိုးလင်းအောင်-မြိတ်','09-795956670',1,1,18,292,'Baik/မြိတ်','Baik/မြိတ်',1,1,'2021-01-06 03:51:57',1,'2021-01-06 03:51:57',NULL),(30,'C00030','ကိုညီ','09422269900',1,1,19,309,'‌ေဒါပံု','‌ေဒါပံု',1,2,'2021-01-21 07:47:01',2,'2021-01-21 07:47:01',NULL),(31,'C00031','ရမဥ်  - ေမာ်လမြိုင်(စက်မှုဇုန်)','09-255961431',1,1,10,181,'ေမာ်လမြိုင်(စက်မှုဇုန်)','ေမာ်လမြိုင်(စက်မှုဇုန်)',1,2,'2021-01-29 07:22:19',2,'2021-01-29 07:22:19',NULL),(32,'C00032','ရမဥ်  - ေမာ်လမြိုင်(လမိုင်းေတာင်ပြင်)','09-425347917',1,1,10,181,'ေမာ်လမြိုင်(လမိုင်းေတာင်ပြင်)','ေမာ်လမြိုင်(လမိုင်းေတာင်ပြင်)',1,2,'2021-01-29 09:25:42',2,'2021-01-29 09:25:42',NULL),(33,'C00033','ကိုမင်းဇော်','-',2,1,3,44,'-','-',1,1,'2021-02-03 05:34:39',1,'2021-02-03 05:34:39',NULL);
/*!40000 ALTER TABLE `customers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `financial_types`
--

DROP TABLE IF EXISTS `financial_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `financial_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(120) NOT NULL,
  `type` varchar(30) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `financial_types`
--

LOCK TABLES `financial_types` WRITE;
/*!40000 ALTER TABLE `financial_types` DISABLE KEYS */;
INSERT INTO `financial_types` VALUES (1,'Sale','type2'),(2,'Purchase','type2'),(3,'Income','type2'),(4,'Expense','type2'),(5,'CA','type2'),(6,'NCA','type2'),(7,'CL','type2'),(8,'NCL','type2'),(9,'Equity & Liabilities','type2'),(10,'P&L','type1'),(11,'Balance Sheet','type1');
/*!40000 ALTER TABLE `financial_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inventory_adjustment`
--

DROP TABLE IF EXISTS `inventory_adjustment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `inventory_adjustment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `invoice_no` varchar(255) NOT NULL,
  `reference_no` varchar(255) NOT NULL,
  `adjustment_date` date NOT NULL,
  `branch_id` int(11) NOT NULL,
  `warehouse_id` int(11) NOT NULL,
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` int(11) NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `invoice_no` (`invoice_no`),
  UNIQUE KEY `reference_no` (`reference_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inventory_adjustment`
--

LOCK TABLES `inventory_adjustment` WRITE;
/*!40000 ALTER TABLE `inventory_adjustment` DISABLE KEYS */;
/*!40000 ALTER TABLE `inventory_adjustment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mainwarehouse_entries`
--

DROP TABLE IF EXISTS `mainwarehouse_entries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mainwarehouse_entries` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entry_no` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `entry_date` date NOT NULL,
  `warehouse_id` int(11) NOT NULL,
  `branch_id` int(11) DEFAULT NULL,
  `reference_no` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` int(11) NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `reference_no` (`reference_no`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mainwarehouse_entries`
--

LOCK TABLES `mainwarehouse_entries` WRITE;
/*!40000 ALTER TABLE `mainwarehouse_entries` DISABLE KEYS */;
/*!40000 ALTER TABLE `mainwarehouse_entries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order_approval_product`
--

DROP TABLE IF EXISTS `order_approval_product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `order_approval_product` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `approval_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `uom_id` int(11) NOT NULL,
  `approval_qty` int(11) NOT NULL,
  `price` decimal(13,2) DEFAULT '0.00',
  `price_variant` decimal(13,2) DEFAULT NULL,
  `total_amount` int(11) DEFAULT '0',
  `is_foc` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_approval_product`
--

LOCK TABLES `order_approval_product` WRITE;
/*!40000 ALTER TABLE `order_approval_product` DISABLE KEYS */;
/*!40000 ALTER TABLE `order_approval_product` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order_approvals`
--

DROP TABLE IF EXISTS `order_approvals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `order_approvals` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `approval_no` varchar(255) NOT NULL,
  `order_id` int(11) NOT NULL,
  `order_no` varchar(255) NOT NULL,
  `total_amount` int(11) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '0',
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` int(11) NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_approvals`
--

LOCK TABLES `order_approvals` WRITE;
/*!40000 ALTER TABLE `order_approvals` DISABLE KEYS */;
/*!40000 ALTER TABLE `order_approvals` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_no` varchar(255) NOT NULL,
  `order_date` date NOT NULL,
  `branch_id` int(11) DEFAULT NULL,
  `warehouse_id` int(11) DEFAULT NULL,
  `customer_id` int(11) NOT NULL,
  `sale_man_id` int(11) DEFAULT NULL,
  `total_amount` int(11) NOT NULL,
  `cash_discount` int(11) DEFAULT NULL,
  `net_total` int(11) NOT NULL,
  `tax` int(11) DEFAULT NULL,
  `tax_amount` int(11) DEFAULT NULL,
  `balance_amount` int(11) NOT NULL,
  `order_status` varchar(10) NOT NULL DEFAULT 'Draft',
  `remark` longtext CHARACTER SET utf8,
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` int(11) NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `order_no` (`order_no`)
) ENGINE=MyISAM AUTO_INCREMENT=26 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orders`
--

LOCK TABLES `orders` WRITE;
/*!40000 ALTER TABLE `orders` DISABLE KEYS */;
INSERT INTO `orders` VALUES (6,'SO00001','2021-01-06',1,NULL,31,2,14296650,NULL,14296650,NULL,0,14296650,'Draft',NULL,2,'2021-01-29 07:32:05',4,'2021-02-02 05:11:29'),(7,'SO00007','2021-01-06',1,NULL,19,2,3259074,NULL,3259074,NULL,0,3259074,'Draft',NULL,2,'2021-01-29 08:03:56',2,'2021-02-02 08:04:10'),(13,'SO00013','2021-01-06',1,NULL,32,2,13662750,NULL,13662750,NULL,0,13662750,'Draft',NULL,2,'2021-02-02 09:13:20',2,'2021-02-02 09:13:20'),(11,'SO00008','2021-01-06',1,NULL,19,2,2841046,NULL,2841046,NULL,0,2841046,'Draft',NULL,2,'2021-02-02 08:24:27',2,'2021-02-02 08:24:27'),(12,'SO00012','2021-01-06',1,NULL,30,2,4258100,NULL,4258100,NULL,0,4258100,'Draft',NULL,2,'2021-02-02 08:52:22',2,'2021-02-02 08:52:22'),(14,'SO00014','2021-01-11',1,NULL,14,2,2600000,NULL,2600000,NULL,0,2600000,'Draft',NULL,2,'2021-02-02 09:24:31',2,'2021-02-02 09:24:31'),(15,'SO00015','2021-01-11',1,NULL,20,2,8466850,NULL,8466850,NULL,0,8466850,'Draft',NULL,2,'2021-02-02 09:33:34',2,'2021-02-02 09:33:34'),(16,'SO00016','2021-01-09',1,NULL,27,2,1537200,NULL,1537200,NULL,0,1537200,'Draft',NULL,2,'2021-02-02 09:39:53',2,'2021-02-02 09:39:53'),(17,'SO00017','2021-01-12',1,NULL,21,2,1442700,NULL,1442700,NULL,0,1442700,'Draft',NULL,2,'2021-02-02 09:42:14',2,'2021-02-02 09:42:14'),(18,'SO00018','2021-01-11',1,NULL,20,2,3402000,NULL,3402000,NULL,0,3402000,'Draft',NULL,2,'2021-02-02 09:52:32',2,'2021-02-02 09:52:32'),(19,'SO00019','2021-01-15',1,NULL,11,2,2418000,NULL,2418000,NULL,0,2418000,'Draft',NULL,2,'2021-02-02 09:53:59',2,'2021-02-03 09:29:04'),(20,'SO00020','2021-01-14',1,NULL,27,2,3275700,NULL,3275700,NULL,0,3275700,'Draft',NULL,2,'2021-02-02 10:45:26',2,'2021-02-02 10:45:26'),(21,'SO00021','2021-01-20',1,NULL,4,2,1134600,NULL,1134600,NULL,0,1134600,'Draft',NULL,2,'2021-02-02 10:48:38',2,'2021-02-02 10:48:38'),(22,'SO00022','2021-01-06',1,NULL,11,2,390600,NULL,390600,NULL,0,390600,'Draft',NULL,2,'2021-02-03 05:14:34',2,'2021-02-03 05:14:34'),(23,'SO00023','2021-01-25',1,NULL,30,2,670208,NULL,670208,NULL,0,670208,'Draft',NULL,2,'2021-02-03 05:23:39',2,'2021-02-03 05:23:39'),(24,'SO00024','2021-01-27',1,NULL,33,2,1240000,NULL,1240000,NULL,0,1240000,'Draft',NULL,2,'2021-02-03 06:43:44',2,'2021-02-03 06:43:44'),(25,'SO00025','2021-01-06',1,NULL,31,2,14296650,NULL,14296650,NULL,0,14296650,'Draft',NULL,2,'2021-02-03 06:53:49',2,'2021-02-03 06:53:49');
/*!40000 ALTER TABLE `orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payments`
--

DROP TABLE IF EXISTS `payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cash_payment_no` varchar(120) NOT NULL,
  `date` date NOT NULL,
  `debit_id` int(11) NOT NULL,
  `credit_id` int(11) NOT NULL,
  `amount` bigint(20) NOT NULL,
  `remark` longtext,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` int(11) NOT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `updated_by` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `cash_receipt_no` (`cash_payment_no`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payments`
--

LOCK TABLES `payments` WRITE;
/*!40000 ALTER TABLE `payments` DISABLE KEYS */;
INSERT INTO `payments` VALUES (2,'CP00001','2021-01-05',36,28,336000,'Ko Chan Commission','2021-02-03 09:53:53',4,'2021-02-03 09:53:53',4),(3,'CP00003','2021-01-05',37,28,500,'Online Charges','2021-02-03 09:55:19',4,'2021-02-03 09:55:19',4),(4,'CP00004','2021-01-08',14,28,10,NULL,'2021-02-03 10:11:37',4,'2021-02-03 10:11:37',4),(5,'CP00005','2021-01-08',30,28,10139700,'Deepa ေခ်းေငြျပန္ဆပ္','2021-02-04 05:13:16',4,'2021-02-04 05:13:16',4);
/*!40000 ALTER TABLE `payments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_inventory_adjustment`
--

DROP TABLE IF EXISTS `product_inventory_adjustment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product_inventory_adjustment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) DEFAULT NULL,
  `uom_id` int(11) NOT NULL,
  `adjustment_id` int(11) DEFAULT NULL,
  `add_qty` int(11) DEFAULT NULL,
  `less_qty` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_inventory_adjustment`
--

LOCK TABLES `product_inventory_adjustment` WRITE;
/*!40000 ALTER TABLE `product_inventory_adjustment` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_inventory_adjustment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_mainwarehouse_entry`
--

DROP TABLE IF EXISTS `product_mainwarehouse_entry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product_mainwarehouse_entry` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `entry_id` int(11) NOT NULL,
  `uom_id` int(11) NOT NULL,
  `product_quantity` decimal(13,2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_mainwarehouse_entry`
--

LOCK TABLES `product_mainwarehouse_entry` WRITE;
/*!40000 ALTER TABLE `product_mainwarehouse_entry` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_mainwarehouse_entry` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_order`
--

DROP TABLE IF EXISTS `product_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product_order` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `uom_id` int(11) NOT NULL,
  `product_quantity` int(11) NOT NULL,
  `approved_quantity` int(11) DEFAULT NULL,
  `accepted_quantity` int(11) DEFAULT NULL,
  `wt` varchar(40) DEFAULT NULL,
  `price` decimal(13,2) DEFAULT '0.00',
  `price_variant` decimal(13,2) DEFAULT NULL,
  `rate` int(11) NOT NULL,
  `actual_rate` int(11) NOT NULL DEFAULT '0',
  `discount` int(11) DEFAULT NULL,
  `other_discount` int(11) DEFAULT NULL,
  `total_amount` int(11) DEFAULT '0',
  `is_foc` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=104 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_order`
--

LOCK TABLES `product_order` WRITE;
/*!40000 ALTER TABLE `product_order` DISABLE KEYS */;
INSERT INTO `product_order` VALUES (4,6,3,1,350,NULL,NULL,'1.9kg',0.00,NULL,2500,2500,NULL,NULL,875000,0),(5,6,23,1,150,NULL,NULL,'3.2kg',0.00,NULL,4000,4000,NULL,NULL,600000,0),(6,6,76,1,150,NULL,NULL,'4.6kg',0.00,NULL,5750,5750,NULL,NULL,862500,0),(7,6,35,1,100,NULL,NULL,'5.3kg',0.00,NULL,6625,6625,NULL,NULL,662500,0),(8,6,43,1,200,NULL,NULL,'7.35kg',0.00,NULL,9188,9188,NULL,NULL,1837600,0),(9,6,77,1,250,NULL,NULL,'11.1kg',0.00,NULL,13875,13875,NULL,NULL,3468750,0),(10,6,45,1,100,NULL,NULL,'14.5kg',0.00,NULL,18125,18125,NULL,NULL,1812500,0),(11,6,32,1,250,NULL,NULL,'6.7kg',0.00,NULL,8442,8442,NULL,NULL,2110500,0),(12,6,43,1,225,NULL,NULL,'7.35kg',0.00,NULL,9188,9188,NULL,NULL,2067300,0),(13,7,49,1,52,NULL,NULL,'1.02kg',0.00,NULL,2652,2652,NULL,NULL,137904,0),(14,7,50,1,52,NULL,NULL,'1.5kg',0.00,NULL,3900,3900,NULL,NULL,202800,0),(15,7,51,1,66,NULL,NULL,'2.04kg',0.00,NULL,5304,5304,NULL,NULL,350064,0),(16,7,52,1,50,NULL,NULL,'2.6kg',0.00,NULL,6760,6760,NULL,NULL,338000,0),(17,7,53,1,50,NULL,NULL,'2.8kg',0.00,NULL,7280,7280,NULL,NULL,364000,0),(18,7,54,1,42,NULL,NULL,'4.08kg',0.00,NULL,10608,10608,NULL,NULL,445536,0),(19,7,55,1,38,NULL,NULL,'1.66kg',0.00,NULL,4316,4316,NULL,NULL,164008,0),(20,7,56,1,38,NULL,NULL,'2.24kg',0.00,NULL,5824,5824,NULL,NULL,221312,0),(21,7,57,1,31,NULL,NULL,'2.74kg',0.00,NULL,7124,7124,NULL,NULL,220844,0),(22,7,58,1,19,NULL,NULL,'3.41kg',0.00,NULL,8866,8866,NULL,NULL,168454,0),(50,11,71,1,23,NULL,NULL,'2.61kg',0.00,NULL,6786,6786,NULL,NULL,156078,0),(49,11,70,1,34,NULL,NULL,'4.13kg',0.00,NULL,10738,10738,NULL,NULL,365092,0),(48,11,69,1,26,NULL,NULL,'3.48kg',0.00,NULL,9048,9048,NULL,NULL,235248,0),(47,11,68,1,32,NULL,NULL,'1.99kg',0.00,NULL,5174,5174,NULL,NULL,165568,0),(46,11,67,1,31,NULL,NULL,'3.86kg',0.00,NULL,10036,10036,NULL,NULL,311116,0),(45,11,66,1,30,NULL,NULL,'2.58kg',0.00,NULL,6708,6708,NULL,NULL,201240,0),(44,11,65,1,32,NULL,NULL,'1.96kg',0.00,NULL,5096,5096,NULL,NULL,163072,0),(38,7,59,1,21,NULL,NULL,'4.17kg',0.00,NULL,10842,10842,NULL,NULL,227682,0),(39,7,60,1,29,NULL,NULL,'5.55kg',0.00,NULL,14430,14430,NULL,NULL,418470,0),(40,11,61,1,42,NULL,NULL,'0.87kg',0.00,NULL,2262,2262,NULL,NULL,95004,0),(41,11,62,1,32,NULL,NULL,'2.58kg',0.00,NULL,6708,6708,NULL,NULL,214656,0),(42,11,63,1,20,NULL,NULL,'3.1kg',0.00,NULL,8060,8060,NULL,NULL,161200,0),(43,11,64,1,44,NULL,NULL,'1.54kg',0.00,NULL,4004,4004,NULL,NULL,176176,0),(51,11,72,1,22,NULL,NULL,'3.65kg',0.00,NULL,9490,9490,NULL,NULL,208780,0),(52,11,73,1,33,NULL,NULL,'4.25kg',0.00,NULL,11752,11752,NULL,NULL,387816,0),(53,12,46,1,50,NULL,NULL,NULL,0.00,NULL,17350,17350,NULL,NULL,867500,0),(54,12,78,1,60,NULL,NULL,NULL,0.00,NULL,1100,1100,NULL,NULL,66000,0),(55,12,74,1,504,NULL,NULL,'18',0.00,NULL,4800,4800,NULL,NULL,2419200,0),(56,12,74,1,40,NULL,NULL,'10',0.00,NULL,4800,4800,NULL,NULL,192000,0),(57,12,74,1,36,NULL,NULL,'9',0.00,NULL,4800,4800,NULL,NULL,172800,0),(58,12,47,1,6,NULL,NULL,'58.5kg',0.00,NULL,55000,55000,NULL,NULL,330000,0),(59,12,48,1,2,NULL,NULL,'109.2kg',0.00,NULL,105300,105300,NULL,NULL,210600,0),(60,13,27,1,100,NULL,NULL,'4.2kg',0.00,NULL,5250,5250,NULL,NULL,525000,0),(61,13,41,1,200,NULL,NULL,'4.1kg',0.00,NULL,5125,5125,NULL,NULL,1025000,0),(62,13,42,1,200,NULL,NULL,'4.95kg',0.00,NULL,6188,6188,NULL,NULL,1237600,0),(63,13,37,1,200,NULL,NULL,'5.5kg',0.00,NULL,6875,6875,NULL,NULL,1375000,0),(64,13,35,1,200,NULL,NULL,'5.3kg',0.00,NULL,6625,6625,NULL,NULL,1325000,0),(65,13,32,1,150,NULL,NULL,'6.2kg',0.00,NULL,7750,7750,NULL,NULL,1162500,0),(66,13,43,1,150,NULL,NULL,'7.35kg',0.00,NULL,9188,9188,NULL,NULL,1378200,0),(67,13,44,1,150,NULL,NULL,'14.3kg',0.00,NULL,17875,17875,NULL,NULL,2681250,0),(68,13,45,1,150,NULL,NULL,'15.7kg',0.00,NULL,19688,19688,NULL,NULL,2953200,0),(69,14,40,1,4,NULL,NULL,NULL,0.00,NULL,650000,650000,NULL,NULL,2600000,0),(70,15,38,1,200,NULL,NULL,'6.06kg',0.00,NULL,5818,5818,NULL,NULL,1163600,0),(71,15,38,1,200,NULL,NULL,'6.25kg',0.00,NULL,5933,5933,NULL,NULL,1186600,0),(72,15,38,1,200,NULL,NULL,'8.25kg',0.00,NULL,7508,7508,NULL,NULL,1501600,0),(73,15,39,1,150,NULL,NULL,'9.44kg',0.00,NULL,8779,8779,NULL,NULL,1316850,0),(74,15,39,1,150,NULL,NULL,'10.13kg',0.00,NULL,9421,9421,NULL,NULL,1413150,0),(75,15,39,1,150,NULL,NULL,'13.8kg',0.00,NULL,12567,12567,NULL,NULL,1885050,0),(76,16,36,1,100,NULL,NULL,'7kg',0.00,NULL,8820,8820,NULL,NULL,882000,0),(77,16,37,1,100,NULL,NULL,'5.2kg',0.00,NULL,6552,6552,NULL,NULL,655200,0),(78,17,22,1,100,NULL,NULL,'3.2kg',0.00,NULL,4032,4032,NULL,NULL,403200,0),(79,17,24,1,150,NULL,NULL,'5.5kg',0.00,NULL,6930,6930,NULL,NULL,1039500,0),(80,18,17,1,100,NULL,NULL,'2.35kg',0.00,NULL,2961,2961,NULL,NULL,296100,0),(81,18,22,1,100,NULL,NULL,'3.2kg',0.00,NULL,4032,4032,NULL,NULL,403200,0),(82,18,32,1,100,NULL,NULL,'6.8kg',0.00,NULL,8568,8568,NULL,NULL,856800,0),(83,18,33,1,50,NULL,NULL,'13.4kg',0.00,NULL,16884,16884,NULL,NULL,844200,0),(84,18,34,1,100,NULL,NULL,'7.95kg',0.00,NULL,10017,10017,NULL,NULL,1001700,0),(85,19,31,1,300,NULL,NULL,'6.5kg',0.00,NULL,8060,8060,NULL,NULL,2418000,0),(86,20,29,1,100,NULL,NULL,'9.85KG',0.00,NULL,12017,12017,NULL,NULL,1201700,0),(87,20,30,1,200,NULL,NULL,'8.5KG',0.00,NULL,10370,10370,NULL,NULL,2074000,0),(88,21,46,1,300,NULL,NULL,'3.05KG',0.00,NULL,3782,3782,NULL,NULL,1134600,0),(89,22,80,1,50,NULL,NULL,'6.2kg',0.00,NULL,7812,7812,NULL,NULL,390600,0),(90,23,37,1,20,NULL,NULL,'5.4kg',0.00,NULL,6912,6912,NULL,NULL,138240,0),(91,23,36,1,20,NULL,NULL,'6.7kg',0.00,NULL,8576,8576,NULL,NULL,171520,0),(92,23,30,1,20,NULL,NULL,'8.2kg',0.00,NULL,10496,10496,NULL,NULL,209920,0),(93,23,81,1,8,NULL,NULL,'14.7kg',0.00,NULL,18816,18816,NULL,NULL,150528,0),(94,24,40,2,2,NULL,NULL,NULL,0.00,NULL,620000,620000,NULL,NULL,1240000,0),(95,25,3,1,350,NULL,NULL,'1.9kg',0.00,NULL,2500,2500,NULL,NULL,875000,0),(96,25,23,1,150,NULL,NULL,'3.2kg',0.00,NULL,4000,4000,NULL,NULL,600000,0),(97,25,76,1,150,NULL,NULL,'4.6kg',0.00,NULL,5750,5750,NULL,NULL,862500,0),(98,25,35,1,100,NULL,NULL,'5.3kg',0.00,NULL,6625,6625,NULL,NULL,662500,0),(99,25,43,1,200,NULL,NULL,'7.35kg',0.00,NULL,9188,9188,NULL,NULL,1837600,0),(100,25,77,1,250,NULL,NULL,'11.1kg',0.00,NULL,13875,13875,NULL,NULL,3468750,0),(101,25,45,1,100,NULL,NULL,'14.5kg',0.00,NULL,18125,18125,NULL,NULL,1812500,0),(102,25,32,1,250,NULL,NULL,'6.7kg',0.00,NULL,8442,8442,NULL,NULL,2110500,0),(103,25,43,1,225,NULL,NULL,'7.35kg',0.00,NULL,9188,9188,NULL,NULL,2067300,0);
/*!40000 ALTER TABLE `product_order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_purchase`
--

DROP TABLE IF EXISTS `product_purchase`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product_purchase` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `purchase_id` int(11) DEFAULT NULL,
  `product_id` int(11) NOT NULL,
  `uom_id` int(11) NOT NULL,
  `wt` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `product_quantity` decimal(13,2) NOT NULL,
  `delivered_quantity` decimal(13,2) DEFAULT NULL,
  `price` int(11) DEFAULT '0',
  `price_variant` int(11) DEFAULT NULL,
  `total_amount` int(11) DEFAULT '0',
  `is_foc` tinyint(4) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_purchase`
--

LOCK TABLES `product_purchase` WRITE;
/*!40000 ALTER TABLE `product_purchase` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_purchase` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_sale`
--

DROP TABLE IF EXISTS `product_sale`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product_sale` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sale_id` int(11) NOT NULL,
  `purchase_id` int(11) DEFAULT NULL,
  `product_id` int(11) NOT NULL,
  `order_product_pivot_id` int(11) DEFAULT NULL,
  `uom_id` int(11) NOT NULL,
  `product_quantity` decimal(13,2) NOT NULL,
  `delivered_quantity` decimal(13,2) DEFAULT NULL,
  `price` int(11) DEFAULT '0',
  `price_variant` int(11) DEFAULT NULL,
  `rate` int(11) NOT NULL,
  `actual_rate` int(11) NOT NULL DEFAULT '0',
  `discount` int(11) DEFAULT NULL,
  `other_discount` int(11) DEFAULT NULL,
  `total_amount` int(11) DEFAULT '0',
  `is_foc` tinyint(4) DEFAULT '0',
  `wt` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_sale`
--

LOCK TABLES `product_sale` WRITE;
/*!40000 ALTER TABLE `product_sale` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_sale` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_selling_uom`
--

DROP TABLE IF EXISTS `product_selling_uom`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product_selling_uom` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `uom_id` int(11) NOT NULL,
  `relation` decimal(13,2) NOT NULL,
  `product_price` decimal(13,2) DEFAULT NULL,
  `retail1_price` int(11) DEFAULT NULL,
  `retail2_price` int(11) DEFAULT NULL,
  `wholesale_price` int(11) DEFAULT NULL,
  `per_warehouse_uom_price` decimal(13,2) DEFAULT NULL,
  `warehouse_uom_purchase_price` decimal(10,0) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_selling_uom`
--

LOCK TABLES `product_selling_uom` WRITE;
/*!40000 ALTER TABLE `product_selling_uom` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_selling_uom` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_transfer`
--

DROP TABLE IF EXISTS `product_transfer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product_transfer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `transfer_id` int(11) NOT NULL,
  `uom_id` int(11) NOT NULL,
  `product_quantity` decimal(13,2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_transfer`
--

LOCK TABLES `product_transfer` WRITE;
/*!40000 ALTER TABLE `product_transfer` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_transfer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_transitions`
--

DROP TABLE IF EXISTS `product_transitions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product_transitions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `transition_type` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `transition_entry_id` int(11) DEFAULT NULL,
  `transition_transfer_id` int(11) DEFAULT NULL,
  `transition_approval_id` int(11) DEFAULT NULL,
  `transition_sale_id` int(11) DEFAULT NULL,
  `transition_purchase_id` int(11) DEFAULT NULL,
  `transition_adjustment_id` int(11) DEFAULT NULL,
  `transition_product_pivot_id` int(11) NOT NULL,
  `branch_id` int(11) DEFAULT NULL,
  `warehouse_id` int(11) DEFAULT NULL,
  `transition_date` datetime NOT NULL,
  `transition_product_uom_id` int(11) NOT NULL,
  `transition_product_quantity` decimal(13,2) NOT NULL,
  `product_uom_id` int(11) NOT NULL,
  `product_quantity` decimal(13,2) DEFAULT NULL,
  `cost_price` int(11) DEFAULT NULL,
  `is_revise` tinyint(1) DEFAULT NULL,
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` int(11) NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `product_id` (`product_id`),
  KEY `warehouse_id` (`warehouse_id`),
  KEY `transition_date` (`transition_date`),
  KEY `transition_entry_id` (`transition_entry_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_transitions`
--

LOCK TABLES `product_transitions` WRITE;
/*!40000 ALTER TABLE `product_transitions` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_transitions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `product_code_type` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `product_code` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `brand_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `uom_id` int(11) NOT NULL,
  `selling_price` int(11) DEFAULT NULL,
  `purchase_price` int(11) NOT NULL,
  `product_price` int(11) DEFAULT NULL,
  `cost_price` int(11) DEFAULT NULL,
  `minimum_qty` int(11) NOT NULL,
  `reorder_level` int(11) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` int(11) NOT NULL,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `product_code_2` (`product_code`),
  KEY `product_code` (`product_code`)
) ENGINE=MyISAM AUTO_INCREMENT=82 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products`
--

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` VALUES (1,'GI 1/2\" x 1/2\" (0.8mm) Hollow Pipe','automatic','P00001',1,1,1,5000,4500,NULL,NULL,100,500,1,2,'2021-01-19 07:25:49',2,'2021-01-19 07:25:49',NULL),(2,'GI 1/2\" x 1/2\" (0.9mm) Hollow Pipe','automatic','P00002',1,1,1,5000,4500,NULL,NULL,100,500,1,2,'2021-01-19 07:26:38',2,'2021-01-19 07:26:38',NULL),(3,'GI 1/2\" x 1/2\" (1mm) Hollow Pipe','automatic','P00003',1,1,1,5000,4500,NULL,NULL,100,500,1,4,'2021-01-19 07:40:21',4,'2021-01-19 07:40:21',NULL),(4,'GI 1/2\" x 1/2\" (1.1mm) Hollow Pipe','automatic','P00004',1,1,1,5000,4500,NULL,NULL,100,500,1,4,'2021-01-19 07:41:00',4,'2021-01-19 07:41:00',NULL),(5,'GI 1/2\" x 1/2\" (1.2mm) Hollow Pipe','automatic','P00005',1,1,1,5000,4500,NULL,NULL,100,500,1,4,'2021-01-19 07:41:27',4,'2021-01-19 07:41:27',NULL),(6,'GI 1/2\" x 1/2\" (1.3mm) Hollow Pipe','automatic','P00006',1,1,1,5000,4500,NULL,NULL,100,500,1,4,'2021-01-19 07:42:02',4,'2021-01-19 07:42:02',NULL),(7,'GI 1/2\" x 1/2\" (1.4mm) Hollow Pipe','automatic','P00007',1,1,1,5000,4500,NULL,NULL,100,300,1,4,'2021-01-19 07:42:28',4,'2021-01-19 07:42:28',NULL),(8,'GI 3/4\" x 3/4\" (0.8mm) Hollow Pipe','automatic','P00008',1,1,1,5000,4500,NULL,NULL,100,500,1,4,'2021-01-19 07:43:05',4,'2021-01-19 07:43:05',NULL),(9,'GI 3/4\" x 3/4\" (0.9mm) Hollow Pipe','automatic','P00009',1,1,1,5000,4500,NULL,NULL,100,500,1,4,'2021-01-19 07:43:37',4,'2021-01-19 07:43:37',NULL),(10,'GI 3/4\" x 3/4\" (1mm) Hollow Pipe','automatic','P00010',1,1,1,5000,4500,NULL,NULL,100,500,1,4,'2021-01-19 07:44:14',4,'2021-01-19 07:44:14',NULL),(11,'GI 3/4\" x 3/4\" (1.1mm) Hollow Pipe','automatic','P00011',1,1,1,5000,4500,NULL,NULL,100,500,1,4,'2021-01-19 07:44:40',4,'2021-01-19 07:44:40',NULL),(12,'GI 3/4\" x 3/4\" (1.2mm) Hollow Pipe','automatic','P00012',1,1,1,5000,4500,NULL,NULL,100,500,1,4,'2021-01-19 07:45:05',4,'2021-01-19 07:45:05',NULL),(13,'GI 3/4\" x 3/4\" (1.3mm) Hollow Pipe','automatic','P00013',1,1,1,5000,4500,NULL,NULL,100,500,1,4,'2021-01-19 07:45:30',4,'2021-01-19 07:45:30',NULL),(14,'GI 3/4\" x 3/4\" (1.4mm) Hollow Pipe','automatic','P00014',1,1,1,5000,4500,NULL,NULL,100,500,1,4,'2021-01-19 07:45:57',4,'2021-01-19 07:45:57',NULL),(15,'GI 5/8\" x 5/8\" (0.8mm) Hollow Pipe','automatic','P00015',1,1,1,5000,4500,NULL,NULL,100,500,1,4,'2021-01-19 07:46:37',4,'2021-01-19 07:46:37',NULL),(16,'GI 5/8\" x 5/8\" (0.9mm) Hollow Pipe','automatic','P00016',1,1,1,5000,4500,NULL,NULL,100,500,1,4,'2021-01-19 07:47:30',4,'2021-01-19 07:47:30',NULL),(17,'GI 5/8\" x 5/8\" (1mm) Hollow Pipe','automatic','P00017',1,1,1,5000,4500,NULL,NULL,100,500,1,4,'2021-01-19 07:48:10',4,'2021-01-19 07:48:10',NULL),(18,'GI 5/8\" x 5/8\" (1.1mm) Hollow Pipe','automatic','P00018',1,1,1,5000,4500,NULL,NULL,100,500,1,4,'2021-01-19 07:49:04',4,'2021-01-19 07:49:04',NULL),(19,'GI 5/8\" x 5/8\" (1.2mm) Hollow Pipe','automatic','P00019',1,1,1,5000,4500,NULL,NULL,100,500,1,4,'2021-01-19 07:49:50',4,'2021-01-19 07:49:50',NULL),(20,'GI 5/8\" x 5/8\" (1.3mm) Hollow Pipe','automatic','P00020',1,1,1,5000,4500,NULL,NULL,100,500,1,4,'2021-01-19 07:50:13',4,'2021-01-19 07:50:13',NULL),(21,'GI 5/8\" x 5/8\" (1.4mm) Hollow Pipe','automatic','P00021',1,1,1,5000,4500,NULL,NULL,100,500,1,4,'2021-01-19 07:50:41',4,'2021-01-19 07:50:41',NULL),(22,'GI 1\" x 1\" (0.8mm) Hollow Pipe','automatic','P00022',1,1,1,5000,4500,NULL,NULL,100,500,1,4,'2021-01-19 07:51:43',4,'2021-01-19 07:51:43',NULL),(23,'GI 1\" x 1\" (0.9mm) Hollow Pipe','automatic','P00023',1,1,1,5000,4500,NULL,NULL,100,500,1,4,'2021-01-19 07:52:23',4,'2021-01-19 07:52:23',NULL),(24,'GI 1\" x 1\" (1mm) Hollow Pipe','automatic','P00024',1,1,1,5000,4500,NULL,NULL,100,500,1,4,'2021-01-19 07:53:28',4,'2021-01-19 07:53:28',NULL),(25,'GI 1\" x 1\" (1mm) Hollow Pipe','automatic','P00025',1,1,1,5000,4500,NULL,NULL,100,500,1,4,'2021-01-19 07:53:31',4,'2021-01-19 07:53:31',NULL),(26,'GI 1\" x 1\" (1.1mm) Hollow Pipe','automatic','P00026',1,1,1,5000,4500,NULL,NULL,100,500,1,4,'2021-01-19 07:54:39',4,'2021-01-19 07:54:39',NULL),(27,'GI 1\" x 1\" (1.2mm) Hollow Pipe','automatic','P00027',1,1,1,5000,4500,NULL,NULL,100,500,1,4,'2021-01-19 07:55:40',4,'2021-01-19 07:55:40',NULL),(28,'GI 1\" x 1\" (1.3mm) Hollow Pipe','automatic','P00028',1,1,1,5000,4500,NULL,NULL,100,500,1,4,'2021-01-19 07:56:23',4,'2021-01-19 07:56:23',NULL),(29,'GI 2\" x 2\" (1.4mm) Hollow Pipe','automatic','P00029',1,1,1,10000,12017,NULL,NULL,100,500,1,4,'2021-01-19 07:59:33',4,'2021-01-19 07:59:33',NULL),(30,'GI 3\" x 1 1/2\" (1mm) Hollow Pipe','automatic','P00030',1,1,1,10000,10370,NULL,NULL,100,500,1,4,'2021-01-19 08:00:13',4,'2021-01-19 08:00:13',NULL),(31,'GI 1 1/2\" x 1 1/2\" (1.2mm) Hollow Pipe','automatic','P00031',1,1,1,8000,8060,NULL,NULL,100,500,1,4,'2021-01-19 08:01:16',4,'2021-01-19 08:01:16',NULL),(32,'GI 2\" x 1\" (1.2mm) Hollow Pipe','automatic','P00032',1,1,1,8568,8500,NULL,NULL,100,500,1,4,'2021-01-19 08:03:14',4,'2021-01-19 08:03:14',NULL),(33,'GI 3\" x 3\" (1.2mm) Hollow Pipe','automatic','P00033',1,1,1,16884,16000,NULL,NULL,100,500,1,4,'2021-01-19 08:03:55',4,'2021-01-19 08:03:55',NULL),(34,'GI 2\" x 2\" (1.2mm) Hollow Pipe','automatic','P00034',1,1,1,10017,10000,NULL,NULL,100,500,1,4,'2021-01-19 08:04:36',4,'2021-01-19 08:04:36',NULL),(35,'GI 2\" x 1\" (1mm) Hollow Pipe','automatic','P00035',1,1,1,6930,6900,NULL,NULL,100,500,1,4,'2021-01-19 08:06:02',4,'2021-01-19 08:06:02',NULL),(36,'GI 2\" x 2\" (1mm) Hollow Pipe','automatic','P00036',1,1,1,8820,8800,NULL,NULL,100,500,1,4,'2021-01-19 08:07:42',4,'2021-01-19 08:07:42',NULL),(37,'GI 1 1/2\" x 1 1/2\" (1mm) Hollow Pipe','automatic','P00037',1,1,1,6552,6500,NULL,NULL,100,500,1,4,'2021-01-19 08:08:45',4,'2021-01-19 08:08:45',NULL),(38,'1 1/2 x 1 1/2 Angle','automatic','P00038',5,2,1,5818,5800,NULL,NULL,100,500,1,4,'2021-01-19 08:11:23',4,'2021-01-19 08:11:23',NULL),(39,'2\" x 2\" Angle','automatic','P00039',5,2,1,8779,8000,NULL,NULL,100,500,1,4,'2021-01-19 08:12:35',4,'2021-01-19 08:12:35',NULL),(40,'12mm HRB-400 Deformed Bar','automatic','P00040',4,3,2,650000,630000,NULL,NULL,100,200,1,4,'2021-02-02 09:24:06',2,'2021-02-02 09:24:06',NULL),(41,'GI 1 1/2 x 3/4\" (1mm) Hollow Pipe','automatic','P00041',1,1,1,5125,5000,NULL,NULL,100,300,1,4,'2021-01-19 08:15:41',4,'2021-01-19 08:15:41',NULL),(42,'GI 1 1/2 x 3/4\" (1.2mm) Hollow Pipe','automatic','P00042',1,1,1,6188,6000,NULL,NULL,100,200,1,4,'2021-01-19 08:16:17',4,'2021-01-19 08:16:17',NULL),(43,'GI 2\" x 1\" (1.4mm) Hollow Pipe','automatic','P00043',1,1,1,9188,9100,NULL,NULL,100,200,1,4,'2021-01-19 08:17:26',4,'2021-01-19 08:17:26',NULL),(44,'GI 4\" x 2\" (1.4mm) Hollow Pipe','automatic','P00044',1,1,1,17875,17800,NULL,NULL,100,200,1,4,'2021-01-19 08:18:07',4,'2021-01-19 08:18:07',NULL),(45,'GI 4\" x 2\" (1.5mm) Hollow Pipe','automatic','P00045',1,1,1,19688,19600,NULL,NULL,100,200,1,4,'2021-01-19 08:18:47',4,'2021-01-19 08:18:47',NULL),(46,'1 1/2 GI Round Pipe','automatic','P00046',8,5,1,17350,17000,NULL,NULL,100,200,1,4,'2021-01-19 08:23:36',4,'2021-01-19 08:23:36',NULL),(47,'I Beam 6\" x 3\"','automatic','P00047',2,6,1,55000,45000,NULL,NULL,100,200,1,4,'2021-01-19 08:25:07',4,'2021-01-19 08:25:07',NULL),(48,'I Beam 8\" x 4\"','automatic','P00048',2,6,1,105300,105000,NULL,NULL,100,200,1,4,'2021-01-19 08:25:49',4,'2021-01-19 08:25:49',NULL),(49,'15.8 ST (RO) 0.55','automatic','P00049',9,7,1,2652,2600,NULL,NULL,10,10,1,4,'2021-01-19 08:31:51',4,'2021-01-19 08:31:51',NULL),(50,'19 ST (RO)  0.55','automatic','P00050',9,7,1,3900,3700,NULL,NULL,100,100,1,4,'2021-01-19 08:32:18',4,'2021-01-19 08:32:18',NULL),(51,'25 ST (RO) 0.55','automatic','P00051',9,7,1,5304,5200,NULL,NULL,100,100,1,4,'2021-01-19 08:33:38',4,'2021-01-19 08:33:38',NULL),(52,'31.8 ST (RO) 0.55','automatic','P00052',9,7,1,6760,6700,NULL,NULL,10,10,1,4,'2021-01-19 08:34:29',4,'2021-01-19 08:34:29',NULL),(53,'38.0 ST (RO) 0.55','automatic','P00053',9,7,1,7280,7200,NULL,NULL,10,10,1,4,'2021-01-19 08:35:07',4,'2021-01-19 08:35:07',NULL),(54,'50.8 ST (RO) 0.55','automatic','P00054',9,7,1,10608,10600,NULL,NULL,10,10,1,4,'2021-01-19 08:35:45',4,'2021-01-19 08:35:45',NULL),(55,'15.8 ST (RO) 0.75','automatic','P00055',9,7,1,4316,4300,NULL,NULL,10,10,1,4,'2021-01-19 08:36:21',4,'2021-01-19 08:36:21',NULL),(56,'19 ST (RO)  0.75','automatic','P00056',9,7,1,5824,5800,NULL,NULL,10,10,1,4,'2021-01-19 08:37:08',4,'2021-01-19 08:37:08',NULL),(57,'25 ST (RO) 0.75','automatic','P00057',9,7,1,7124,7100,NULL,NULL,10,10,1,4,'2021-01-19 08:37:53',4,'2021-01-19 08:37:53',NULL),(58,'31.8 ST (RO) 0.75','automatic','P00058',9,7,1,8866,8000,NULL,NULL,10,10,1,4,'2021-01-19 08:38:26',4,'2021-01-19 08:38:26',NULL),(59,'38 ST (RO) 0.75','automatic','P00059',9,7,1,10842,10000,NULL,NULL,10,10,1,4,'2021-01-19 08:39:01',4,'2021-01-19 08:39:01',NULL),(60,'50.8 ST (RO) 0.75','automatic','P00060',9,7,1,14430,14000,NULL,NULL,10,10,1,4,'2021-01-19 08:39:45',4,'2021-01-19 08:39:45',NULL),(61,'12 x 12 ST (SQ) 0.55','automatic','P00061',9,7,1,2262,2000,NULL,NULL,10,10,1,4,'2021-01-19 08:40:26',4,'2021-01-19 08:40:26',NULL),(62,'25 x 25 ST (SQ) 0.55','automatic','P00062',9,7,1,6708,6600,NULL,NULL,100,100,1,4,'2021-01-19 08:40:56',4,'2021-01-19 08:40:56',NULL),(63,'30 x 30 ST (SQ) 0.55','automatic','P00063',9,7,1,8060,8000,NULL,NULL,10,10,1,4,'2021-01-19 08:41:31',4,'2021-01-19 08:41:31',NULL),(64,'10 x 20 ST (REC) 0.55','automatic','P00064',9,7,1,4004,3900,NULL,NULL,10,10,1,4,'2021-01-19 08:42:46',4,'2021-01-19 08:42:46',NULL),(65,'13 x 25 ST (REC) 0.55','automatic','P00065',9,7,1,5096,5000,NULL,NULL,10,10,1,4,'2021-01-19 08:43:54',4,'2021-01-19 08:43:54',NULL),(66,'20 x 40 ST (REC) 0.55','automatic','P00066',9,7,1,6708,6000,NULL,NULL,10,10,1,4,'2021-01-19 08:44:38',4,'2021-01-19 08:44:38',NULL),(67,'25 x 50 ST (REC) 0.55','automatic','P00067',9,7,1,10036,9000,NULL,NULL,10,10,1,4,'2021-01-19 08:45:19',4,'2021-01-19 08:45:19',NULL),(68,'15 x 15 ST (SQ) 0.75','automatic','P00068',9,7,1,5174,5000,NULL,NULL,10,10,1,4,'2021-01-19 08:46:11',4,'2021-01-19 08:46:11',NULL),(69,'25 x 25 ST (SQ) 0.75','automatic','P00069',9,7,1,9048,8000,NULL,NULL,10,10,1,4,'2021-01-19 08:47:10',4,'2021-01-19 08:47:10',NULL),(70,'30 x 30 ST (SQ) 0.75','automatic','P00070',9,7,1,10738,10000,NULL,NULL,10,10,1,4,'2021-01-19 08:48:04',4,'2021-01-19 08:48:04',NULL),(71,'13 x 26 ST (REC) 0.75','automatic','P00071',9,7,1,6786,6000,NULL,NULL,10,10,1,4,'2021-01-19 08:49:07',4,'2021-01-19 08:49:07',NULL),(72,'20 x 40 ST (REC) 0.75','automatic','P00072',9,7,1,9490,9400,NULL,NULL,10,10,1,4,'2021-01-19 08:49:38',4,'2021-01-19 08:49:38',NULL),(73,'25 x 50 ST (REC) 0.75','automatic','P00073',9,7,1,11752,11000,NULL,NULL,10,10,1,4,'2021-01-19 08:50:08',4,'2021-01-19 08:50:08',NULL),(74,'DS Black 3\"','automatic','P00074',10,8,1,4800,4500,NULL,NULL,10,10,1,4,'2021-01-19 08:52:21',4,'2021-01-19 08:52:21',NULL),(75,'GI 1/2\" x 1/2\" (1mm) Hollow Pipe','automatic','P00075',1,1,1,2500,2000,NULL,NULL,10,10,1,4,'2021-01-19 08:55:50',4,'2021-01-19 08:55:50',NULL),(76,'GI 1 1/2\" x 1 1/2\" (0.9mm) Hollow Pipe','automatic','P00076',1,1,1,5750,5700,NULL,NULL,10,10,1,4,'2021-01-19 08:58:22',4,'2021-01-19 08:58:22',NULL),(77,'GI 3\" x 1 1/2\" (1.4mm) Hollow Pipe','automatic','P00077',1,1,1,13875,13000,NULL,NULL,10,10,1,4,'2021-01-19 08:59:46',4,'2021-01-19 08:59:46',NULL),(78,'ငြမ်းကလစ်','automatic','P00078',8,5,1,1100,1000,NULL,NULL,10,10,1,2,'2021-01-19 09:24:54',2,'2021-01-19 09:24:54',NULL),(79,'1\" x 1/2\" GI 1mm','automatic','P00079',8,5,1,7812,7000,NULL,NULL,100,200,0,2,'2021-02-03 03:23:51',2,'2021-02-03 03:23:51',NULL),(80,'GI 1\" x 1/2\"  1mm','automatic','P00080',1,5,1,7812,7000,NULL,NULL,100,200,1,2,'2021-02-03 03:56:21',2,'2021-02-03 03:56:21',NULL),(81,'GI 4\"x2\" 1.2mm','automatic','P00081',1,1,1,18800,18000,NULL,NULL,100,200,1,2,'2021-02-03 03:56:05',2,'2021-02-03 03:56:05',NULL);
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `purchase_invoices`
--

DROP TABLE IF EXISTS `purchase_invoices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `purchase_invoices` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `invoice_no` varchar(100) NOT NULL,
  `reference_no` varchar(100) DEFAULT NULL,
  `invoice_date` date NOT NULL,
  `branch_id` int(11) DEFAULT NULL,
  `warehouse_id` int(11) NOT NULL,
  `supplier_id` int(11) NOT NULL,
  `office_purchase_man_id` int(11) DEFAULT NULL,
  `order_id` int(11) DEFAULT NULL,
  `is_revise` tinyint(4) NOT NULL DEFAULT '0',
  `order_approval_id` int(11) DEFAULT NULL,
  `total_amount` int(11) NOT NULL,
  `pay_amount` int(11) NOT NULL,
  `discount` int(11) NOT NULL DEFAULT '0',
  `balance_amount` int(11) NOT NULL,
  `collection_amount` int(11) NOT NULL DEFAULT '0',
  `purchase_type` tinyint(4) NOT NULL,
  `payment_type` varchar(10) NOT NULL,
  `is_opening` int(11) NOT NULL DEFAULT '0',
  `due_date` date DEFAULT NULL,
  `credit_day` int(11) DEFAULT NULL,
  `edit_count` int(11) NOT NULL DEFAULT '0',
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` int(11) NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `purchase_invoices`
--

LOCK TABLES `purchase_invoices` WRITE;
/*!40000 ALTER TABLE `purchase_invoices` DISABLE KEYS */;
INSERT INTO `purchase_invoices` VALUES (1,'OBP00001',NULL,'2020-12-16',1,1,1,NULL,NULL,0,NULL,3625200,0,0,3625200,0,0,'credit',1,NULL,NULL,0,1,'2021-01-06 10:56:20',1,'2021-01-06 10:56:20'),(2,'OBP00002',NULL,'2020-12-18',1,1,1,NULL,NULL,0,NULL,3504200,0,0,3504200,0,0,'credit',1,NULL,NULL,0,1,'2021-01-06 10:56:30',1,'2021-01-06 10:56:30'),(3,'OBP00003',NULL,'2020-12-22',1,1,1,NULL,NULL,0,NULL,2920090,0,0,2920090,0,0,'credit',1,NULL,NULL,0,1,'2021-01-06 10:56:40',1,'2021-01-06 10:56:40'),(4,'OBP00004',NULL,'2020-12-22',1,1,1,NULL,NULL,0,NULL,10899800,0,0,10899800,0,0,'credit',1,NULL,NULL,0,1,'2021-01-06 10:57:16',1,'2021-01-06 10:57:16'),(5,'OBP00005',NULL,'2020-12-23',1,1,1,NULL,NULL,0,NULL,1787500,0,0,1787500,0,0,'credit',1,NULL,NULL,0,1,'2021-01-06 10:57:33',1,'2021-01-06 10:57:33'),(6,'OBP00006',NULL,'2020-12-30',1,1,1,NULL,NULL,0,NULL,1091200,0,0,1091200,0,0,'credit',1,NULL,NULL,0,1,'2021-01-06 10:57:50',1,'2021-01-06 10:57:50'),(7,'OBP00007',NULL,'2020-12-15',1,1,2,NULL,NULL,0,NULL,19582200,0,0,19582200,0,0,'credit',1,NULL,NULL,0,1,'2021-01-06 11:00:51',1,'2021-01-06 11:00:51'),(8,'OBP00008',NULL,'2020-12-19',1,1,2,NULL,NULL,0,NULL,570240,0,0,570240,0,0,'credit',1,NULL,NULL,0,1,'2021-01-06 11:01:06',1,'2021-01-06 11:01:06'),(10,'OBP00010',NULL,'2020-12-29',1,1,2,NULL,NULL,0,NULL,13805000,0,0,13805000,0,0,'credit',1,NULL,NULL,0,1,'2021-01-06 11:01:17',1,'2021-01-06 11:01:17'),(11,'OBP00011',NULL,'2020-12-29',1,1,2,NULL,NULL,0,NULL,1952000,0,0,1952000,0,0,'credit',1,NULL,NULL,0,1,'2021-01-06 11:01:27',1,'2021-01-06 11:01:27'),(12,'OBP00012',NULL,'2020-12-30',1,1,2,NULL,NULL,0,NULL,1586000,0,0,1586000,0,0,'credit',1,NULL,NULL,0,1,'2021-01-06 11:01:35',1,'2021-01-06 11:01:35'),(13,'OBP00013',NULL,'2020-12-22',1,1,3,NULL,NULL,0,NULL,6508000,0,0,6508000,0,0,'credit',1,NULL,NULL,0,1,'2021-01-06 11:02:15',1,'2021-01-06 11:02:15'),(14,'OBP00014',NULL,'2020-12-22',1,1,3,NULL,NULL,0,NULL,7249545,0,0,7249545,0,0,'credit',1,NULL,NULL,0,1,'2021-01-06 11:03:03',1,'2021-01-06 11:03:03'),(15,'OBP00015',NULL,'2020-12-23',1,1,4,NULL,NULL,0,NULL,2192902,0,0,2192902,0,0,'credit',1,NULL,NULL,0,1,'2021-01-06 11:03:47',1,'2021-01-06 11:03:47');
/*!40000 ALTER TABLE `purchase_invoices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `receipts`
--

DROP TABLE IF EXISTS `receipts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `receipts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cash_receipt_no` varchar(120) NOT NULL,
  `date` date NOT NULL,
  `debit_id` int(11) NOT NULL,
  `credit_id` int(11) NOT NULL,
  `amount` bigint(20) NOT NULL,
  `remark` longtext,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` int(11) NOT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `updated_by` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `cash_receipt_no` (`cash_receipt_no`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `receipts`
--

LOCK TABLES `receipts` WRITE;
/*!40000 ALTER TABLE `receipts` DISABLE KEYS */;
INSERT INTO `receipts` VALUES (4,'CR00001','2021-01-05',28,24,2,'Bank ပိုထုတ္','2021-02-03 09:48:22',4,'2021-02-03 09:52:33',4),(5,'CR00005','2021-01-06',28,30,10139700,'Deepa မွေခ်းေငြ','2021-02-03 09:49:03',4,'2021-02-03 09:49:03',4),(6,'CR00006','2021-01-08',28,35,50,'K Star ပိုေငြ','2021-02-03 09:49:42',4,'2021-02-03 09:49:42',4);
/*!40000 ALTER TABLE `receipts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `roles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `role_name` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `role_name` (`role_name`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (1,'system','2020-10-05 06:13:35','2020-03-29 17:30:00'),(2,'admin','2020-10-05 06:13:35','2020-03-29 17:30:00'),(3,'office_user','2020-10-05 06:13:35','2020-03-29 17:30:00'),(4,'office_order_user','2020-10-05 06:13:35','2020-03-29 17:30:00'),(5,'van_user','2020-10-05 06:13:35','2020-03-29 17:30:00'),(6,'Country Head','2020-10-05 06:13:35','0000-00-00 00:00:00'),(7,'Local Supervisor','2020-10-05 06:13:35','0000-00-00 00:00:00'),(8,'delivery','2020-10-05 06:13:35','0000-00-00 00:00:00');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sale_deliveries`
--

DROP TABLE IF EXISTS `sale_deliveries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sale_deliveries` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `delivery_no` varchar(255) NOT NULL,
  `delivery_date` date NOT NULL,
  `sale_id` int(11) NOT NULL,
  `invoice_no` varchar(100) NOT NULL,
  `total_amount` int(11) DEFAULT NULL,
  `status` tinyint(1) DEFAULT '0',
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` int(11) NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sale_deliveries`
--

LOCK TABLES `sale_deliveries` WRITE;
/*!40000 ALTER TABLE `sale_deliveries` DISABLE KEYS */;
/*!40000 ALTER TABLE `sale_deliveries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sale_delivery_product`
--

DROP TABLE IF EXISTS `sale_delivery_product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sale_delivery_product` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sale_id` int(11) NOT NULL,
  `delivery_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `uom_id` int(11) NOT NULL,
  `delivery_qty` decimal(13,2) DEFAULT NULL,
  `price` decimal(13,2) DEFAULT '0.00',
  `price_variant` decimal(13,2) DEFAULT NULL,
  `total_amount` int(11) DEFAULT '0',
  `is_foc` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sale_delivery_product`
--

LOCK TABLES `sale_delivery_product` WRITE;
/*!40000 ALTER TABLE `sale_delivery_product` DISABLE KEYS */;
/*!40000 ALTER TABLE `sale_delivery_product` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sale_mans`
--

DROP TABLE IF EXISTS `sale_mans`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sale_mans` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sale_man` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` int(11) DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sale_mans`
--

LOCK TABLES `sale_mans` WRITE;
/*!40000 ALTER TABLE `sale_mans` DISABLE KEYS */;
/*!40000 ALTER TABLE `sale_mans` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sale_men`
--

DROP TABLE IF EXISTS `sale_men`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sale_men` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sale_man` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` int(11) DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sale_men`
--

LOCK TABLES `sale_men` WRITE;
/*!40000 ALTER TABLE `sale_men` DISABLE KEYS */;
INSERT INTO `sale_men` VALUES (1,'Test','09',1,1,'2021-01-22 05:36:32',NULL,'2021-01-22 05:36:32'),(2,'Wai Chan Min','09-422269900',1,2,'2021-01-29 07:10:48',NULL,'2021-01-29 07:10:48');
/*!40000 ALTER TABLE `sale_men` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sales`
--

DROP TABLE IF EXISTS `sales`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sales` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `invoice_no` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `reference_no` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `invoice_date` date NOT NULL,
  `branch_id` int(11) DEFAULT NULL,
  `warehouse_id` int(11) DEFAULT NULL,
  `customer_id` int(11) NOT NULL,
  `office_sale_man_id` int(11) DEFAULT NULL,
  `order_id` int(11) DEFAULT NULL,
  `is_revise` tinyint(1) DEFAULT '0',
  `order_approval_id` int(11) DEFAULT NULL,
  `total_amount` int(11) NOT NULL,
  `cash_discount` int(11) DEFAULT NULL,
  `net_total` int(11) NOT NULL,
  `tax` int(11) DEFAULT NULL,
  `tax_amount` int(11) DEFAULT NULL,
  `pay_amount` int(11) NOT NULL,
  `discount` int(11) DEFAULT '0',
  `balance_amount` int(11) NOT NULL,
  `sale_type` tinyint(1) DEFAULT NULL,
  `payment_type` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_opening` int(11) NOT NULL DEFAULT '0',
  `due_date` date DEFAULT NULL,
  `credit_day` int(11) DEFAULT NULL,
  `collection_amount` int(11) DEFAULT '0',
  `delivery_approve` tinyint(1) DEFAULT '0',
  `delivery_status` varchar(10) COLLATE utf8_unicode_ci DEFAULT 'Draft',
  `edit_count` int(11) DEFAULT '0',
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` int(11) NOT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `invoice_no` (`invoice_no`)
) ENGINE=MyISAM AUTO_INCREMENT=23 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sales`
--

LOCK TABLES `sales` WRITE;
/*!40000 ALTER TABLE `sales` DISABLE KEYS */;
INSERT INTO `sales` VALUES (16,'OBP00016',NULL,'2020-12-18',1,1,18,NULL,NULL,0,NULL,4229700,NULL,0,NULL,NULL,0,0,4229700,1,'credit',1,NULL,NULL,4229700,0,'Draft',0,1,'2021-01-06 10:50:15',1,'2021-02-03 09:04:49'),(15,'OBP00015',NULL,'2020-12-28',1,1,19,NULL,NULL,0,NULL,5210000,NULL,0,NULL,NULL,0,0,5210000,1,'credit',1,NULL,NULL,0,0,'Draft',0,1,'2021-01-06 10:49:43',1,'2021-01-06 10:49:43'),(14,'OBP00014',NULL,'2020-12-23',1,1,19,NULL,NULL,0,NULL,2342419,NULL,0,NULL,NULL,0,0,2342419,1,'credit',1,NULL,NULL,0,0,'Draft',0,1,'2021-01-06 10:49:31',1,'2021-01-06 10:49:31'),(13,'OBP00013',NULL,'2020-12-22',1,1,19,NULL,NULL,0,NULL,15271200,NULL,0,NULL,NULL,0,0,15271200,1,'credit',1,NULL,NULL,15271200,0,'Draft',0,1,'2021-01-06 10:49:16',1,'2021-02-03 09:11:04'),(12,'OBP00012',NULL,'2020-12-30',1,1,20,NULL,NULL,0,NULL,2834000,NULL,0,NULL,NULL,0,0,2834000,1,'credit',1,NULL,NULL,0,0,'Draft',0,1,'2021-01-06 10:48:09',1,'2021-01-06 10:48:09'),(11,'OBP00011',NULL,'2020-12-12',1,1,20,NULL,NULL,0,NULL,7330950,NULL,0,NULL,NULL,0,0,7330950,1,'credit',1,NULL,NULL,7330950,0,'Draft',0,1,'2021-01-06 10:47:36',1,'2021-01-21 07:39:46'),(10,'OBP00010',NULL,'2020-12-17',1,1,21,NULL,NULL,0,NULL,1842500,NULL,0,NULL,NULL,0,0,1842500,1,'credit',1,NULL,NULL,1842500,0,'Draft',0,1,'2021-01-06 10:46:56',1,'2021-02-03 09:05:36'),(9,'OBP00001',NULL,'2020-12-23',1,1,27,NULL,NULL,0,NULL,1859000,NULL,0,NULL,NULL,0,0,1859000,1,'credit',1,NULL,NULL,1859000,0,'Draft',0,1,'2021-01-06 10:45:47',1,'2021-02-03 09:08:32'),(17,'OBP00017',NULL,'2020-12-12',1,1,17,NULL,NULL,0,NULL,10364400,NULL,0,NULL,NULL,0,0,10364400,1,'credit',1,NULL,NULL,0,0,'Draft',0,1,'2021-01-06 10:50:39',1,'2021-01-06 10:50:39'),(18,'OBP00018',NULL,'2020-12-05',1,1,7,NULL,NULL,0,NULL,5674400,NULL,0,NULL,NULL,0,0,5674400,1,'credit',1,NULL,NULL,5674400,0,'Draft',0,1,'2021-01-06 10:51:40',1,'2021-02-03 09:11:46'),(19,'OBP00019',NULL,'2020-12-11',1,1,7,NULL,NULL,0,NULL,1992683,NULL,0,NULL,NULL,0,0,1992683,1,'credit',1,NULL,NULL,1992683,0,'Draft',0,1,'2021-01-06 10:51:54',1,'2021-02-03 09:13:29'),(20,'OBP00020',NULL,'2020-12-16',1,1,4,NULL,NULL,0,NULL,3739200,NULL,0,NULL,NULL,0,0,3739200,1,'credit',1,NULL,NULL,3739200,0,'Draft',0,1,'2021-01-06 10:52:41',1,'2021-02-03 09:26:45'),(21,'OBP00021',NULL,'2020-12-22',1,1,4,NULL,NULL,0,NULL,3013800,NULL,0,NULL,NULL,0,0,3013800,1,'credit',1,NULL,NULL,0,0,'Draft',0,1,'2021-01-06 10:52:56',1,'2021-01-06 10:52:56'),(22,'OBP00022',NULL,'2020-12-28',1,1,19,NULL,NULL,0,NULL,2044100,NULL,0,NULL,NULL,0,0,2044100,1,'credit',1,NULL,NULL,0,0,'Draft',0,1,'2021-01-12 06:33:40',1,'2021-01-12 06:33:40');
/*!40000 ALTER TABLE `sales` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `states`
--

DROP TABLE IF EXISTS `states`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `states` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `state_name` varchar(255) CHARACTER SET utf8 NOT NULL,
  `country_id` int(11) NOT NULL,
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` int(11) NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=22 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `states`
--

LOCK TABLES `states` WRITE;
/*!40000 ALTER TABLE `states` DISABLE KEYS */;
INSERT INTO `states` VALUES (1,'Ayeyarwady/ဧရာဝတီ',1,1,'2021-01-06 03:41:42',1,'2021-01-06 03:41:42'),(2,'Bago(East)/ပဲခူး(အရှေ့)',1,1,'2021-01-06 03:41:42',1,'2021-01-06 03:41:42'),(3,'Bago(West)/ပဲခူး(အနောက်)',1,1,'2021-01-06 03:41:42',1,'2021-01-06 03:41:42'),(4,'Chin/ချင်း',1,1,'2021-01-06 03:41:42',1,'2021-01-06 03:41:42'),(5,'Kachin/ကချင်',1,1,'2021-01-06 03:41:42',1,'2021-01-06 03:41:42'),(6,'Kayah/ကယား',1,1,'2021-01-06 03:41:42',1,'2021-01-06 03:41:42'),(7,'Kayin/ကရင်',1,1,'2021-01-06 03:41:42',1,'2021-01-06 03:41:42'),(8,'Magway/မ ကေ ွး',1,1,'2021-01-06 03:41:42',1,'2021-01-06 03:41:42'),(9,'Mandalay/မန္တလေး',1,1,'2021-01-06 03:41:42',1,'2021-01-06 03:41:42'),(10,'Mon/မ ွန်',1,1,'2021-01-06 03:41:42',1,'2021-01-06 03:41:42'),(11,'Nay Pyi Taw/နေပြည်တော်',1,1,'2021-01-06 03:41:42',1,'2021-01-06 03:41:42'),(12,'Rakhine/ရခိုင်',1,1,'2021-01-06 03:41:42',1,'2021-01-06 03:41:42'),(13,'Sagaing/စစ်ကိုင်း',1,1,'2021-01-06 03:41:42',1,'2021-01-06 03:41:42'),(14,'Shan/ရှမ်း',1,1,'2021-01-06 03:41:42',1,'2021-01-06 03:41:42'),(15,'Shan(South)/ရှမ်း(တောင်)',1,1,'2021-01-06 03:41:42',1,'2021-01-06 03:41:42'),(16,'Shan(North)/ရှမ်း(အနောက်)',1,1,'2021-01-06 03:41:42',1,'2021-01-06 03:41:42'),(17,'Shan(East)/ရှမ်း(အရှေ့)',1,1,'2021-01-06 03:41:42',1,'2021-01-06 03:41:42'),(18,'Tanintharyi/တနင်္သာရီ',1,1,'2021-01-06 03:41:42',1,'2021-01-06 03:41:42'),(19,'Yangon/ရန်ကုန်',1,1,'2021-01-06 03:41:42',1,'2021-01-06 03:41:42'),(20,'Kyaikto/ကျိုက်ထို',1,1,'2021-01-06 03:51:57',1,'2021-01-06 03:51:57'),(21,'Nyaungshwe Township/ညောင်ရွှေ',1,1,'2021-01-06 03:51:57',1,'2021-01-06 03:51:57');
/*!40000 ALTER TABLE `states` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sub_accounts`
--

DROP TABLE IF EXISTS `sub_accounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sub_accounts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sub_account_name` varchar(255) NOT NULL,
  `account_type_id` int(11) NOT NULL,
  `account_head_id` int(11) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` int(11) NOT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `updated_by` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sub_accounts`
--

LOCK TABLES `sub_accounts` WRITE;
/*!40000 ALTER TABLE `sub_accounts` DISABLE KEYS */;
INSERT INTO `sub_accounts` VALUES (5,'Purchase Account',2,14,1,'2020-09-29 20:57:42',1,'2021-01-06 02:49:50',1),(6,'Purchase Advance',4,11,1,'2020-09-29 22:41:04',1,'2021-01-06 02:50:57',1),(7,'Credit Payment',4,11,1,'2020-09-29 23:11:31',1,'2021-01-06 02:51:17',1),(8,'Meter Bill',3,16,1,'2020-09-30 02:45:07',1,'2021-01-06 02:47:14',1),(9,'Sale Advance',4,11,1,'2020-09-30 02:45:48',1,'2021-01-06 02:49:05',1),(10,'Credit Collection',4,11,1,'2020-09-30 02:46:16',1,'2021-01-06 02:45:39',1),(11,'Opening Cash Balance',3,10,1,'2020-10-01 23:50:51',1,'2020-10-01 23:50:51',0),(12,'Cash Sale',4,11,1,'2020-12-17 22:52:18',1,'2020-12-17 22:52:18',0),(13,'Cash Purchase',4,11,1,'2020-12-17 22:55:14',1,'2020-12-17 22:55:14',0),(14,'Discount Allowed',3,16,1,'2020-12-18 01:47:52',1,'2020-12-18 01:47:52',0),(20,'Interest',3,19,1,'2020-12-29 08:13:03',1,'2020-12-29 08:13:03',0),(21,'Oil Charges',3,16,1,'2020-12-29 08:13:36',1,'2020-12-29 08:13:36',0),(23,'Sale Account',1,9,1,'2021-01-06 02:08:24',1,'2021-01-06 02:08:24',0),(24,'Discount Receive',3,19,1,'2021-01-06 02:09:00',1,'2021-01-06 02:46:34',1),(26,'Bank in hand',5,11,1,'2021-01-19 04:56:29',1,'2021-01-27 03:15:50',1),(27,'Trade Receiable',1,11,1,'2021-01-19 04:57:11',1,'2021-01-19 04:57:11',0),(28,'Cash in hand',5,11,1,'2021-01-19 04:58:06',1,'2021-01-27 03:11:30',1),(29,'Trade Payable',2,23,1,'2021-01-19 05:03:49',1,'2021-01-19 05:03:49',0),(30,'Loan From Deepa',3,23,1,'2021-01-19 05:05:32',1,'2021-01-19 05:05:32',0),(31,'SME Loan',3,23,1,'2021-01-19 05:05:50',1,'2021-01-19 05:05:50',0),(32,'K-Star Payable',3,23,1,'2021-01-19 05:06:07',1,'2021-01-19 05:06:07',0),(33,'Loan From Mptt',3,23,1,'2021-01-19 05:06:23',1,'2021-01-19 05:06:23',0),(34,'RETAIN EARNING',3,24,1,'2021-01-26 05:59:06',1,'2021-01-26 05:59:06',0),(35,'Other Income',3,19,1,'2021-02-03 09:46:29',4,'2021-02-03 09:46:29',0),(36,'Commission',3,16,1,'2021-02-03 09:53:14',4,'2021-02-03 09:53:14',0),(37,'Bank Charges',3,16,1,'2021-02-03 09:54:39',4,'2021-02-03 09:54:39',0);
/*!40000 ALTER TABLE `sub_accounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `suppliers`
--

DROP TABLE IF EXISTS `suppliers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `suppliers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` char(225) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `phone_number` char(255) DEFAULT NULL,
  `country_id` int(11) NOT NULL,
  `state_id` int(11) NOT NULL,
  `township_id` int(11) NOT NULL,
  `supplier_shipping_address` text NOT NULL,
  `supplier_billing_address` text NOT NULL,
  `is_active` tinyint(4) NOT NULL DEFAULT '1',
  `supplier_code` varchar(255) NOT NULL,
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` int(11) NOT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `supplier_code` (`supplier_code`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `suppliers`
--

LOCK TABLES `suppliers` WRITE;
/*!40000 ALTER TABLE `suppliers` DISABLE KEYS */;
INSERT INTO `suppliers` VALUES (1,'ကြေးအိုးကြီး-ဇေကမ္ဘာ','09-267755772,09267755773 09-267755774,09-26775577',1,19,347,'-','-',1,'S00001',1,'2021-01-06 03:59:21',1,'2021-01-06 04:04:05',NULL),(2,'AtZ - လွင်ဦးဋ္ဌေး-စော်ဘွားကြီးကုန်း','09-428189151,09-449249647,09-260798064',1,19,347,'-','-',1,'S00002',1,'2021-01-06 03:59:54',1,'2021-01-06 04:04:22',NULL),(3,'Iron King -မြောင်းတကာ','09-964997929,09-699952998',1,19,347,'-','-',1,'S00003',1,'2021-01-06 04:00:17',1,'2021-01-06 04:04:37',NULL),(4,'ကိုကျော်သန်း-တောင်ဒဂုံ','09-5158754',1,19,338,'-','-',1,'S00004',1,'2021-01-06 04:00:35',1,'2021-01-06 11:04:23',NULL),(5,'ငွေဇင်ယော်-စော်ဘွားကြီးကုန်း','09-3640299,3642751',1,19,347,'-','-',1,'S00005',1,'2021-01-06 04:01:12',1,'2021-01-06 04:05:08',NULL),(6,'Myanmar Pules Zone-ကိုအောင်လွင်','09-5037642,09-428181511',1,19,347,'-','-',1,'S00006',1,'2021-01-06 04:01:31',1,'2021-01-06 04:05:23',NULL),(7,'ကိုအောင်နိုင်ဟိန်း(Marvel Steel Group)','09-254187228',1,19,347,'-','-',1,'S00007',1,'2021-01-06 04:01:59',1,'2021-01-06 04:05:40',NULL);
/*!40000 ALTER TABLE `suppliers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `townships`
--

DROP TABLE IF EXISTS `townships`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `townships` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `township_name` varchar(255) CHARACTER SET utf8 NOT NULL,
  `state_id` int(11) NOT NULL,
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` int(11) NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `township_name` (`township_name`)
) ENGINE=MyISAM AUTO_INCREMENT=350 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `townships`
--

LOCK TABLES `townships` WRITE;
/*!40000 ALTER TABLE `townships` DISABLE KEYS */;
INSERT INTO `townships` VALUES (1,'Bogalay/ဘိုက လေး',1,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(2,'Da Nu Phyu/ဓနုဖြူ',1,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(3,'Dedaye/ဒေးဒရဲ',1,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(4,'Eain Mel/အိမ်မဲ',1,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(5,'Hinthata/ဟင်္သာတ',1,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(6,'Ingapu/အင်းဂပူ',1,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(7,'Kangyidaunk Township/ကန်ကြီးတောက်',1,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(8,'Kyaik lat/ကျိုက်လတ်',1,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(9,'Kyan Khinn/ကြံခင်း',1,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(10,'Kyaunggon/ကျောင်းကုန်း',1,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(11,'Kyon Pyaw/ကျုံပျော်',1,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(12,'Kyone Ma Nge/ကျုံမ ငေး',1,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(13,'Labutta/လပ္ပတ္တာ',1,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(14,'Laymyethna Township/',1,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(15,'Ma u bin/ မအူပင်',1,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(16,'Mawlamyine Kyun/မော်ကျွန်း',1,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(17,'Myan Aung/မြန်အောင်',1,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(18,'Myaung Mya/မြောင်းမြ',1,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(19,'Ngapudaw Township/ငပုတော',1,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(20,'Nyaung Don/ညောင်တုန်း',1,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(21,'Pan Ta Naw/ပန်းတ နော်',1,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(22,'Pathein/ပုသိမ်',1,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(23,'Pya Pon/ဖျာပုံ',1,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(24,'Thabaung Township/သဘောင်',1,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(25,'War Khel Ma/ဝါးခယ်မ',1,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(26,'Yekyi Township/ရေကြီး',1,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(27,'Zalun Township/ဇလုံ',1,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(28,'Bago/ပဲခူး',2,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(29,'Daik Oo/ဒိုက်ဦး',2,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(30,'Gyobingauk/ကြို့ပင်ကောက်',3,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(31,'Kawa Township/ကဝ',2,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(32,'Kyaukkyi Township/ကျောက်ကြီး',2,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(33,'Kyauktaga/ကျောက်တံခါး',2,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(34,'Letpadan Township/လက်ပတန်း',3,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(35,'Min Hla/မင်းလှ',3,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(36,'Monyo Township/မုံရွာ',3,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(37,'Nat Ta Lin/နတ်တလင်း',3,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(38,'Nyaung Chay htauk/ညောင်ခြေထောက်',3,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(39,'Nyaung Le Bin/ညောင်လေးပင်',2,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(40,'Ok Pho/အုတ်ဖို',3,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(41,'Oktwin Township/အုတ်တ ွင်း',2,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(42,'Padaung Township/ပန်ထောင်',3,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(43,'Pauk Kaung/ပေါက်ခေါင်း',3,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(44,'Paung De/ပေါင်းတည်',3,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(45,'Pyay/ပြည်',3,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(46,'Pyu/ဖြူး',2,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(47,'Shwedaung Township/ရွှေထောင်',3,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(48,'Shwegyin Township/ရွှေကျင်',2,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(49,'Swar/ဆ ွာ',3,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(50,'Tantabin Township/ထန်းတပင်',2,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(51,'Taungoo/တောင်ငူ',2,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(52,'Tha-nat-pin/သနပ်ပင်',2,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(53,'Thar Ga Ya/သာဂရ',3,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(54,'Thayarwady Township/သာယာဝတီ',3,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(55,'Thegon Township/သဲဂွန်',3,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(56,'Thonesal/သုံးဆယ်',3,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(57,'Waw/ဝေါ',2,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(58,'Yedashe Township/ရဲဒရှီ',2,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(59,'Zay Ya Waddy/ဇေယျဝတီ',3,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(60,'Zigon Township/ဇီဂွန်',3,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(61,'Falam Township/ဖလန်',4,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(62,'Haka Township/ဟကာ',4,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(63,'Htantlang Township/ထန့်လန်',4,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(64,'Kan Pat Lat/ကန်ပက်လက်',4,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(65,'Matupi Township/မတူပီ',4,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(66,'Mindat Township/မင်းဒက်',4,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(67,'Paletwa Township/ပုလဲတွား',4,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(68,'Tiddim Township/တီဒင်',4,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(69,'Ton Zang Township/တွန်ဇန်',4,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(70,'Bawlakhe Township/ဘော်လခီ',5,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(71,'Bhamo Township/ဘာမို',5,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(72,'Chipwi Township/ချီဝီ',5,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(73,'Demoso Township/ဒီမိုဆို',5,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(74,'Hpapun Township/ဖာပွန်',5,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(75,'Hpar Kant/ဖားကန့်',5,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(76,'Hpasawng Township/ဖားဆောင်း',5,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(77,'Hpruso Township/ပရုစို',5,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(78,'Hsawlaw Township/ဆော်လော်',5,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(79,'Injangyang Township/အင်ဂျန်ယန်',5,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(80,'Kawkareik Township/ကော်ကာရိတ်',5,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(81,'Kawnglanghpu Township/ကောင်းလန်းပူ',5,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(82,'Kyain Seikgyi Township/ကျိမ်း',5,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(83,'Machanbaw Township/မချန်ဘော်',5,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(84,'Mansi Township/မန်ဆီ',5,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(85,'Mese Township/မဲဆီ',5,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(86,'Mogaung/မိုးကောင်း',5,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(87,'Mohnyin/မိုးညှင်း',5,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(88,'Momauk Township/မိုမောက်',5,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(89,'Myitkyinar/မြစ်ကြီးနား',5,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(90,'Myo Hla/မြို့လှ',5,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(91,'Nogmung Township/နိုမန်း',5,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(92,'Putao Township/ပူတာအို',5,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(93,'Shadaw Township/ရှဲဒေါ',5,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(94,'Shwegu Township/ရွှေဂူ',5,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(95,'Sumprabum Township/ဆူပရာဘမ်',5,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(96,'Tanai Township/တနိုင်',5,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(97,'Thandang Township/သန်းဒန်',5,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(98,'Waingmaw Township/ဝိုင်းမော်',5,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(99,'Kamine/ကားမိုင်းမြို့',5,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(100,'Sainhtaung/ဆိုင်းတောင်မြို့',5,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(101,'Tonemani/တုံ့မဏီမြို့',5,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(102,'Nanya/နန့်ယားမြို့',5,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(103,'Nanmati/နမ္မတီးမြို့',5,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(104,'Pinbaw/ပင်းဘောမြို့',5,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(105,'Minkone/မင်းကုန်းမြို့',5,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(106,'Shinbwe/ရှင်ဗွေယန်မြို့',5,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(107,'Shadusut/ရှဒူစွတ်မြို့',5,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(108,'Lawah/လဝါးမြို့',5,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(109,'LoneKhin/လုံးခင်းမြို့',5,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(110,'Naungmi/နှောင်းမှီမြို့',5,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(111,'Mawlu/မော်လူးမြို့',5,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(112,'Banmaw/ဗန်းမော်',5,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(113,'Loikaw/လွိုင်ကော်',6,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(114,'Hlaingbwe /လှိုင်းဘွဲ့',7,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(115,'Hpa An/ဖားအံ',7,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(116,'Myawaddy/မြဝတီ',7,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(117,'Aung Lan/အောင်လံ',8,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(118,'Chauk/ချောက်',8,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(119,'Gangaw/ဂန့် ဂေါ်',8,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(120,'Kan Ma/ကံမ',8,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(121,'Magway/မ ကေ ွး',8,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(122,'Min Bu/မင်းဘူး',8,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(123,'Mindon Township/မင်းဒွန်',8,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(124,'Minhla Township/မင်းလှ',8,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(125,'Myaing/မြိုင်',8,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(126,'Myothit Township/မြို့သစ်',8,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(127,'Natmauk Township/နက်မောက်',8,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(128,'Ngape Township/ငပီ',8,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(129,'Pauk/ပေါက်',8,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(130,'PKKU/ပခုက္ကူ',8,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(131,'Pwintbyu Township/ပွင့်ဗျူ',8,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(132,'Sa Lin/စလင်း',8,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(133,'Saw/ဆော',8,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(134,'Seikphyu Township /ဆိပ်ဖြူ',8,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(135,'Sidoktaya Township/စီဒေါက်တယ',8,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(136,'Sin Phyu Kyun/ဆင်ဖြူကျွန်း',8,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(137,'Sinbaungwe Township /ဆင်ဘောင်းဂွေး',8,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(138,'Taung Twin Gyi/တောင်တွင်းကြီး',8,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(139,'Taungdwingyi Township/တောင်းတွင်းကြီး',8,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(140,'Tha Yat/သရက်',8,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(141,'Tilin Township /တီလင်း',8,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(142,'Yae Nan Chaung/ရေနံချောင်း',8,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(143,'Yaesakyo/ရေစကြို',8,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(144,'Amarapura Township/အမရပူရ',9,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(145,'Aungmyethazan Township/အောင်မြဲသဇင်',9,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(146,'Bagan/ပုဂံ',9,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(147,'Chanayethazan Township/ချမ်းအေးသဇင်',9,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(148,'Chanmyathazi Township/ချမ်းမြသဇင်',9,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(149,'Kyauk Pa Daung/ကျောက်ပန်းတောင်း',9,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(150,'Kyauk Se/ကျောက်ဆည်',9,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(151,'Kyaukpadaung Township/ကျောက်ပထောင်း',9,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(152,'Ma Hlaing/မလှိုင်',9,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(153,'Madaya Township/မဒရ',9,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(154,'Mahaaungmye Township/မဟာအောင်မြဲ',9,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(155,'MDY/မန္တလေး',9,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(156,'Meiktila/မိတ္ထီလာ',9,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(157,'Mogok/မိုးကုတ်',9,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(158,'Myin gyan/မြင်းခြံ',9,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(159,'Myittha Township/မေတ္တာ',9,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(160,'Natogyi Township/နာတိုကြီး',9,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(161,'Nganzun Township/ဂန်ဇွန်',9,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(162,'Nyaung-U Township/ညောင်ဦး',9,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(163,'Patheingyi Township/ပုသိမ်',9,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(164,'Pyaw Bwel/ပျော်ဘ ွယ်',9,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(165,'Pyigyidagun Township/ပြည်ကြီးဒဂွန်',9,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(166,'Pyin Oo Lwin/ပြင်ဦးလ ွင်',9,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(167,'Shwe Bo/ရွှေဘို',9,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(168,'Singu Township/ဆင်ဂူ',9,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(169,'Sintgaing Township/ဆင့်ဂိုင်း',9,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(170,'Tada-U Township/တဒဦး',9,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(171,'Taung Thar/တောင်သာ',9,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(172,'Thabeikkyin Township/သဘိတ်ဂျင်း',9,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(173,'Thazi Township/သဇင်',9,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(174,'Wundwin Township/ဝန်ဒွင်း',9,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(175,'Ya Mel Thin/ရမည်းသင်း',9,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(176,'Bilin Township/ဘီလင်း',10,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(177,'Chaungzon Township/ချောင်းဇွန်',10,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(178,'Kyaik Kha Me/ကျိုက်က္ခမီ',10,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(179,'Kyaikmaraw Township/ကြိုက်မရော',10,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(180,'Kyaikto/ကျိုက်ထို',10,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(181,'MLM/မော်လမြိုင်',10,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(182,'Mu Don/မုဒုံ',10,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(183,'Paung Township/ပေါင်',10,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(184,'Thanbyuzayat/သံဖြူဇရပ်',10,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(185,'Thaton/သထုံ',10,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(186,'Yae/ရေး',10,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(187,'Ye Township/ရဲ',10,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(188,'Dekkhinathiri Township/ဒခီနသီရီ',11,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(189,'Le we/လယ်ဝေး',11,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(190,'Nay Pyi Taw/နေပြည်တော်',11,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(191,'Ottarathiri Township/အုတ်တရသီရီ',11,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(192,'Pobbathiri Township/ပေါ့ဘသီရီ',11,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(193,'Pyin Ma Nar/ပျဉ်းမနား',11,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(194,'Tat Kone/တပ်ကုန်း',11,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(195,'Zabuthiri Township/ဇဘူသီရီ',11,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(196,'Zeyathiri Township/ဇေယျသီရီ',11,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(197,'Ann Township/အန်း',12,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(198,'Buthidaung Township/ဘူးသီးတောင်း',12,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(199,'Gaw Township/ဂေါ်',12,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(200,'Kyauk Phyu/ကျောက်ဖြူ',12,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(201,'Kyauk Taw/ကျောက်တော်',12,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(202,'Manaung Township/မနောင်း',12,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(203,'Maungdaw Township/မောင်း',12,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(204,'Minbya/မင်းပြား',12,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(205,'Mrauk U/မြောက်ဦး',12,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(206,'Mye Bon/မြေပုံ',12,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(207,'Pauktaw Township/ပေါက်တော',12,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(208,'Pon Na Gyun/ပုဏ္ဏာကျွန်း',12,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(209,'Ramree Township/ရာမ်ရီ',12,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(210,'Rathedaung Township/ရသဲတောင်',12,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(211,'Sittwe/စစ်တေ ွ',12,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(212,'Taunggok/တောင်ကုတ်',12,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(213,'Than dwe/သံတ ွဲ',12,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(214,'Ayadaw Township/အရဒေါ',13,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(215,'Banmauk Township/ဘန်းမောက်',13,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(216,'Budalin Township/ဘုဓလင်',13,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(217,'Chaung-U Township/ချောင်းဦး',13,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(218,'Hkamti Township/ခမ်းတီ',13,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(219,'Homalin Township/ဟိုမလင်',13,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(220,'Indaw Township/အင်းဒေါ',13,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(221,'Kalay/က လေး',13,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(222,'Kale Township (Kalemyo Township)/ကလဲ့မြို',13,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(223,'Kalewa Township/ကလဲ့ဝ',13,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(224,'Kanbalu Township/ကန်ဘလု',13,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(225,'Kani Township/ကနီ',13,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(226,'Katha Township/ကသ',13,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(227,'Kawlin/ကောလင်း',13,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(228,'Khin-U Township/ခင်-ဦး',13,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(229,'Kyun Hla/ကျွန်းလှ',13,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(230,'Lahe Township/လဟီ',13,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(231,'Lay Shi Township (Lashe Township)/လေးရှီ',13,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(232,'Mawlaik Township/မော်လိပ်ခ်',13,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(233,'Mingin Township/မင်းဂျင်း',13,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(234,'Monywa/မုံရွှာ',13,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(235,'Myaung Township/မြောင်း',13,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(236,'Myinmu Township/မြင်မူ',13,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(237,'Nanyun Township/နန်ရွန်',13,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(238,'Pale Township/ပုလဲ',13,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(239,'Paungbyin Township/ပေါင်ဘင်',13,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(240,'Pinlebu Township/ပင်လဲဘူး',13,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(241,'Sagaing/စစ်ကိုင်း',13,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(242,'Salingyi Township/ဆလင်းကြီး',13,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(243,'Shwebo Township/ရွှေဘို',13,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(244,'Tabayin Township/တဘရင်',13,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(245,'Tamu Township/တာမူ',13,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(246,'Taze Township/တာဇီ',13,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(247,'Tigyaing Township/တစ်ရိုင်',13,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(248,'Wetlet Township/ဝက်လက်',13,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(249,'Wuntho Township/ဝန်းသို',13,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(250,'Ye-U Township/ရဲဦး',13,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(251,'Yinmabin Township/ရင်မဘင်',13,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(252,'Aung Ban/အောင်ပန်း',14,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(253,'Ayetharyar/အေးသာယာ',14,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(254,'Hopong Township/ဟိုပွန်',15,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(255,'Hopang/ဟိုပုံး',16,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(256,'Hsi Hseng Township/ဆီဆန်',15,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(257,'Kalaw/က လော',15,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(258,'Kengtung/ကျိုင်းတုံ',17,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(259,'Kyaing Lap (Kenglap)/ကျိုင်းလက်',14,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(260,'Kyauk me/ကျောက်မဲ',14,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(261,'Kyethi Township/ကျဲသီး',15,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(262,'Lai-Hka Township/လိုင်ကာ',15,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(263,'Langkho Township/လန်ခို',15,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(264,'Lashio/လားရှိုး',16,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(265,'Lauk Kaing /လောက်ကိုင်',14,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(266,'Lawksawk Township/လောဆွက်',15,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(267,'LoiLen/လွိုင်လင်',15,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(268,'Mawkmai Township/မောက်မီ',15,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(269,'Mong Hpayak Township/',14,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(270,'Mong Hsat Township/မွန်ဆတ်',17,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(271,'Mong Hsu Township/မွန်ဆု',15,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(272,'Mong Khet Township/မွန်ခက်',17,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(273,'Mong Kung Township/မွန်ကွန်',15,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(274,'Mong Nai Township/မွန်နိုင်',15,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(275,'Mong Pan Township/မွန်ပန်',15,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(276,'Mong Ping Township/မွန်ပင်',17,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(277,'Mong Tong Township/မွန်တွန်',17,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(278,'Mong Yang Township/မွန်ယန်',17,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(279,'Mong Yawng Township/မွန်ယောင်',17,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(280,'Mu Se/မူဆယ်',16,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(281,'Nansang Township/နန်းဆန်',15,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(282,'Nyaungshwe Township/ညောင်ရွှေ',15,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(283,'Pan Long/ပင်လောင်း',14,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(284,'Pekon Township/ပီကွန်',15,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(285,'Pingdaya Township/ပင်းတယ',15,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(286,'Pinlaung Township/ပင်လောင်',15,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(287,'Pone Inn/ပုန်းအင်း',14,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(288,'Ta Chi Leik/တာချီလိတ်',17,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(289,'Taung Gyi/တောင်ကြီး',15,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(290,'Thi Paw/သီပေါ',14,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(291,'Ywangan Township/ရွမ်ဂန်',15,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(292,'Baik/မြိတ်',18,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(293,'Bokpyin Township/ဘုတ်ပျင်း',18,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(294,'Dawei/ထားဝယ်',18,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(295,'Kawthoung/ကော့သောင်း',18,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(296,'Kort Muu/ကော့မှူး',18,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(297,'Kyunsu Township/ကျွန်းစု',18,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(298,'Launglon Township/လောင်လွန်',18,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(299,'Palaw/ပုလော',18,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(300,'Tanintharyi Township/တနသာင်္ရီ',18,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(301,'Thayetchaung Township/သရက်ချောင်း',18,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(302,'Yebyu Township/ရဲဗျူ',18,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(303,'Alone/အလုံ',19,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(304,'Bahan/ဗဟန်း',19,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(305,'Botataung Township/ဘိုတထောင်',19,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(306,'Cocokyun Township/ကိုကိုးကျွန်း',19,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(307,'Dagon/ ဒဂုံ',19,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(308,'Dala Township/ဒလ',19,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(309,'Dawbon Township/ဒေါပုံ',19,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(310,'East Dagon Township/တောင်ဒဂုံ',19,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(311,'Hlaing Taryar/လှိုင်သာယာ',19,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(312,'Hlaing/လှိုင်',19,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(313,'Hlegu/လှည်းကူး',19,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(314,'Hmawbi Township/မှော်ဘီ',19,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(315,'Htantabin Township/ထန်းတပင်',19,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(316,'Insein/အင်းစိန်',19,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(317,'Kamayut/ကမာရွှတ်',19,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(318,'Kawhmu Township',19,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(319,'Kayan Township/ကယန်း',19,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(320,'Kun Chan Kone/ကွမ်းခြံကုန်း',19,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(321,'Kyauk Tan/ကျောက်တန်း',19,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(322,'Kyauktada/ကျောက်တံတား',19,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(323,'Kyimyindaing/ကြည့်မြင်တိုင်',19,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(324,'Lanmadaw Township/လမ်းမတော်',19,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(325,'Lathar/လသာ',19,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(326,'Maw Be/မှော်ဘီ',19,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(327,'Mayangon/မရမ်းကုန်း',19,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(328,'Mingalar Taungnyut/မင်္ဂလာတောင်ညွှန့်',19,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(329,'Mingalardon/မင်္ဂလာဒုံ',19,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(330,'North Dagon/မြောက်ဒဂုံ',19,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(331,'North Oakkalarpa/မြောက်ဥက္ကလာပ',19,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(332,'Pabedan/ပန်းဘဲတန်',19,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(333,'Pazuntaung/ပုဇွန်တောင်',19,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(334,'San Chaung /စမ်းချောင်း',19,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(335,'Seikkan Township/ဆိပ်ကမ်း',19,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(336,'Seikkyi Kanaungto Township/ဆိပ်ကြီး',19,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(337,'Shwe Pyi Thar/ရွှေပြည်သာ',19,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(338,'South Dagon/တောင်ဒဂုံ',19,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(339,'South Oakkalarpa/တောင်ဥက္ကလာပ',19,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(340,'Taik Kyi/တိုက်ကြီး',19,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(341,'Tamwe/တာမေ ွ',19,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(342,'Tarkayta/သာကေတ',19,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(343,'Thanlyin/သန်လျင်',19,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(344,'Thingangyun/သင်္ဃန်းကျွန်း',19,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(345,'Thongwa/သုံးခွ',19,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(346,'Twan Te/တ ွံတေး',19,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(347,'Yangon/ရန်ကုန်',19,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(348,'Yankin/ရန်ကင်း',19,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25'),(349,'Phaekhone/ဖယ်ခုံ',6,1,'2021-01-06 03:51:25',1,'2021-01-06 03:51:25');
/*!40000 ALTER TABLE `townships` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transfers`
--

DROP TABLE IF EXISTS `transfers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `transfers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `transfer_no` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `transfer_date` date NOT NULL,
  `branch_id` int(11) DEFAULT NULL,
  `from_warehouse_id` int(11) NOT NULL,
  `to_warehouse_id` int(11) NOT NULL,
  `received_by` int(11) DEFAULT NULL,
  `received_date` date DEFAULT NULL,
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` int(11) NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `transfer_no` (`transfer_no`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transfers`
--

LOCK TABLES `transfers` WRITE;
/*!40000 ALTER TABLE `transfers` DISABLE KEYS */;
/*!40000 ALTER TABLE `transfers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `uoms`
--

DROP TABLE IF EXISTS `uoms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `uoms` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uom_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` int(11) NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uom_name` (`uom_name`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `uoms`
--

LOCK TABLES `uoms` WRITE;
/*!40000 ALTER TABLE `uoms` DISABLE KEYS */;
INSERT INTO `uoms` VALUES (1,'Pcs',1,2,'2021-01-19 07:23:12',0,'2021-01-19 07:23:12'),(2,'Ton',1,2,'2021-02-02 09:17:33',0,'2021-02-02 09:17:33');
/*!40000 ALTER TABLE `uoms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `role_id` int(11) DEFAULT NULL,
  `branch_id` int(11) DEFAULT NULL,
  `country_head_id` int(11) DEFAULT NULL,
  `local_supervisor_id` int(11) DEFAULT NULL,
  `phone` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `remember_token` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `warehouse_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `online_status` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'System','systemns@mail.com','$2y$10$vvhl5.38vAApzzFg2g97BOTNPhXNjW5wQIIz6iYEIC3ZcuzFqi3k6',1,1,NULL,NULL,NULL,'',1,'2020-12-30 16:03:49','2020-08-05 22:47:22',0),(2,'Admin 1','admin1@nischalsaneesh.company','$2y$10$XxwyZ1Dpa.b5CuZa2quMUOOafaNGWBlAiRVKejiViCr5sLkz9V7Y6',2,1,NULL,NULL,'09','',1,'2021-02-03 10:34:35','2021-02-03 10:34:35',0),(3,'Admin 2','admin2@nischalsaneesh.company','$2y$10$m7On21ESAIIdRzEUp3qEFe1PTELWR.cSeZEa1/JHP2enDvAl0Oy7K',2,1,NULL,NULL,'09','',1,'2021-01-22 08:34:58','2021-01-22 08:34:58',0),(4,'Admin 3','admin3@nischalsaneesh.company','$2y$10$Rg/WYYfZgjmcszr1oftG4OIARvlPfjCqe3svGsRmXcTvSMiv9kK6q',2,1,NULL,NULL,'09','',1,'2021-02-04 06:48:40','2021-02-04 06:48:40',1),(5,'office sale 1','os1@nischalsaneesh.company','$2y$10$2H2QiyTqNT982X0ksDxr3eiICjjcUIEBXjc5Hs5DsIVL26YgLxd5y',3,1,NULL,NULL,'09','',1,'2021-02-04 05:01:54','2021-02-04 05:01:54',0),(6,'office sale 2','os2@nischalsaneesh.company','$2y$10$HVKVVG.vr.grRI57YGqeMOAPZn4p/YwdMFDm/WHCSI9gk18fMqrCK',3,1,NULL,NULL,'09','',1,'2021-02-03 08:59:48','2021-02-03 08:59:48',0);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `warehouses`
--

DROP TABLE IF EXISTS `warehouses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `warehouses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `warehouse_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `warehouse_type` int(11) DEFAULT NULL,
  `branch_id` int(11) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT '1',
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` int(11) NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `vehicle_number` (`warehouse_name`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `warehouses`
--

LOCK TABLES `warehouses` WRITE;
/*!40000 ALTER TABLE `warehouses` DISABLE KEYS */;
INSERT INTO `warehouses` VALUES (1,'Main Warehouse',1,1,1,1,'2020-10-05 07:03:37',1,'2020-08-10 17:30:00');
/*!40000 ALTER TABLE `warehouses` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-02-05 17:32:05
